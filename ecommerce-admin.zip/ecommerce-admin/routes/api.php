<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\ProductController as AdminProductController;
use App\Http\Controllers\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\Admin\InventoryController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\InvoiceController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\Admin\ReportsController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\SubcategoryController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Public customer routes
Route::get('/products', [ProductController::class, 'index']);
Route::get('/products/featured', [ProductController::class, 'featured']);
Route::get('/products/new-arrivals', [ProductController::class, 'newArrivals']);
Route::get('/products/carousel', [ProductController::class, 'carousel']);
Route::get('/products/debug', [ProductController::class, 'debugProducts']);
Route::get('/products/{product}', [ProductController::class, 'show']);
Route::get('/categories', [CategoryController::class, 'index']);
Route::get('/categories/{category}', [CategoryController::class, 'show']);
Route::get('/categories/{category}/subcategories', [SubcategoryController::class, 'getByCategory']);
Route::get('/subcategories', [SubcategoryController::class, 'index']);
Route::get('/subcategories/{subcategory}', [SubcategoryController::class, 'show']);

// Public Settings
Route::get('/settings/public', [App\Http\Controllers\Admin\SettingsController::class, 'public']);

Route::post('/cart/calculate', [CartController::class, 'calculate']);
Route::post('/orders', [OrderController::class, 'store']);
Route::get('/orders/{order}', [OrderController::class, 'show']);

// Admin routes
Route::post('/admin/login', [AuthController::class, 'login']);
Route::post('/admin/signup', [AuthController::class, 'signup']);
Route::post('/admin/forgot-password', [AuthController::class, 'forgotPassword']);
Route::post('/admin/reset-password', [AuthController::class, 'resetPassword']);

// Protected admin routes
Route::middleware(['auth:sanctum'])->prefix('admin')->group(function () {
    
    // Auth routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
    
    // Dashboard & Reports
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::get('/reports/sales', [ReportController::class, 'sales']);
    Route::get('/reports/inventory', [ReportController::class, 'inventory']);
    Route::get('/reports/orders', [ReportController::class, 'orders']);
    
    // Categories
    Route::apiResource('categories', AdminCategoryController::class);
    
    // Subcategories
    Route::apiResource('subcategories', SubcategoryController::class);
    Route::post('/subcategories/{subcategory}/toggle-status', [SubcategoryController::class, 'toggleStatus']);
    
    // Products
    Route::get('/products/next-id', [AdminProductController::class, 'nextId']);
    Route::apiResource('products', AdminProductController::class);
    
    // Orders Management
    Route::get('/orders/stats', [App\Http\Controllers\Admin\OrderController::class, 'getStats']);
    Route::apiResource('orders', App\Http\Controllers\Admin\OrderController::class);
    Route::patch('/orders/{order}/status', [App\Http\Controllers\Admin\OrderController::class, 'updateStatus']);
    Route::patch('/orders/{order}/payment-status', [App\Http\Controllers\Admin\OrderController::class, 'updatePaymentStatus']);
    
    // Inventory Management
    Route::get('/inventory/stats', [App\Http\Controllers\Admin\InventoryController::class, 'getInventoryStats']);
    Route::get('/inventory/low-stock', [App\Http\Controllers\Admin\InventoryController::class, 'getLowStock']);
    Route::post('/inventory/bulk-update', [App\Http\Controllers\Admin\InventoryController::class, 'bulkUpdateStock']);
    Route::post('/inventory/{product}/adjust', [App\Http\Controllers\Admin\InventoryController::class, 'adjustStock']);
    Route::get('/inventory/{product}/history', [App\Http\Controllers\Admin\InventoryController::class, 'getInventoryHistory']);
    Route::apiResource('inventory', App\Http\Controllers\Admin\InventoryController::class)->only(['index', 'show', 'update']);
    
    // Reports & Analytics
    Route::get('/reports/sales', [App\Http\Controllers\Admin\ReportController::class, 'salesReport']);
    Route::get('/reports/product-sales', [App\Http\Controllers\Admin\ReportController::class, 'productSalesReport']);
    Route::get('/reports/export-sales', [App\Http\Controllers\Admin\ReportController::class, 'exportSalesReport']);
    
    // Comprehensive Reports
    Route::get('/reports/dashboard-stats', [ReportsController::class, 'getDashboardStats']);
    Route::get('/reports/sales', [ReportsController::class, 'getSalesReport']);
    Route::get('/reports/product-sales', [ReportsController::class, 'getProductSales']);
    Route::get('/reports/customer-stats', [ReportsController::class, 'getCustomerStats']);
    Route::get('/reports/top-customers', [ReportsController::class, 'getTopCustomers']);
    Route::get('/reports/revenue', [ReportsController::class, 'getRevenueReport']);
    Route::get('/reports/expenses', [ReportsController::class, 'getExpenseReport']);
    Route::get('/reports/profit-loss', [ReportsController::class, 'getProfitLossReport']);
    Route::get('/reports/tax', [ReportsController::class, 'getTaxReport']);
    
    // Settings
    Route::get('/settings', [App\Http\Controllers\Admin\SettingsController::class, 'index']);
    Route::post('/settings', [App\Http\Controllers\Admin\SettingsController::class, 'update']);
    Route::get('/settings/{key}', [App\Http\Controllers\Admin\SettingsController::class, 'show']);
    Route::post('/settings/reset', [App\Http\Controllers\Admin\SettingsController::class, 'reset']);
    
    // Notifications
    Route::get('/notifications', [App\Http\Controllers\Admin\NotificationController::class, 'index']);
    Route::post('/notifications/{id}/read', [App\Http\Controllers\Admin\NotificationController::class, 'markAsRead']);
    Route::post('/notifications/read-all', [App\Http\Controllers\Admin\NotificationController::class, 'markAllAsRead']);
    Route::delete('/notifications', [App\Http\Controllers\Admin\NotificationController::class, 'destroy']);
    Route::post('/notifications/check-low-stock', [App\Http\Controllers\Admin\NotificationController::class, 'checkLowStock']);
    Route::get('/notifications/unread-count', [App\Http\Controllers\Admin\NotificationController::class, 'unreadCount']);
    
    // Invoices
    Route::get('/invoices', [InvoiceController::class, 'index']);
    Route::post('/invoices/{order}/generate', [InvoiceController::class, 'generate']);
    Route::post('/invoices/{invoice}/pdf', [InvoiceController::class, 'generatePDF']);
    Route::patch('/invoices/{invoice}/paid', [InvoiceController::class, 'markPaid']);
    Route::get('/invoices/{invoice}', [InvoiceController::class, 'show']);
    Route::get('/invoices/{invoice}/download', [InvoiceController::class, 'download']);
});
