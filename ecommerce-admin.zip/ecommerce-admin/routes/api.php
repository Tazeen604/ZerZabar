<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\ProductController as AdminProductController;
use App\Http\Controllers\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\Admin\InventoryController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\InvoiceController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\SubcategoryController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Public customer routes
Route::get('/products', [ProductController::class, 'index']);
Route::get('/products/featured', [ProductController::class, 'featured']);
Route::get('/products/new-arrivals', [ProductController::class, 'newArrivals']);
Route::get('/products/carousel', [ProductController::class, 'carousel']);
Route::get('/products/{product}', [ProductController::class, 'show']);
Route::get('/categories', [CategoryController::class, 'index']);
Route::get('/categories/{category}', [CategoryController::class, 'show']);
Route::get('/categories/{category}/subcategories', [SubcategoryController::class, 'getByCategory']);
Route::get('/subcategories', [SubcategoryController::class, 'index']);
Route::get('/subcategories/{subcategory}', [SubcategoryController::class, 'show']);
Route::post('/cart/calculate', [CartController::class, 'calculate']);
Route::post('/orders', [OrderController::class, 'store']);
Route::get('/orders/{order}', [OrderController::class, 'show']);

// Admin routes
Route::post('/admin/login', [AuthController::class, 'login']);
Route::post('/admin/signup', [AuthController::class, 'signup']);
Route::post('/admin/forgot-password', [AuthController::class, 'forgotPassword']);
Route::post('/admin/reset-password', [AuthController::class, 'resetPassword']);

// Protected admin routes
Route::middleware(['auth:sanctum'])->prefix('admin')->group(function () {
    
    // Auth routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
    
    // Dashboard & Reports
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::get('/reports/sales', [ReportController::class, 'sales']);
    Route::get('/reports/inventory', [ReportController::class, 'inventory']);
    Route::get('/reports/orders', [ReportController::class, 'orders']);
    
    // Categories
    Route::apiResource('categories', AdminCategoryController::class);
    
    // Subcategories
    Route::apiResource('subcategories', SubcategoryController::class);
    Route::post('/subcategories/{subcategory}/toggle-status', [SubcategoryController::class, 'toggleStatus']);
    
    // Products
    Route::get('/products/next-id', [AdminProductController::class, 'nextId']);
    Route::apiResource('products', AdminProductController::class);
    
    // Inventory
    Route::get('/inventory', [InventoryController::class, 'index']);
    Route::get('/inventory/low-stock', [InventoryController::class, 'lowStockReport']);
    Route::post('/inventory/{product}/adjust', [InventoryController::class, 'adjustStock']);
    Route::get('/inventory/{product}/history', [InventoryController::class, 'history']);
    
    // Orders
    Route::get('/orders', [AdminOrderController::class, 'index']);
    Route::get('/orders/{order}', [AdminOrderController::class, 'show']);
    Route::patch('/orders/{order}/status', [AdminOrderController::class, 'updateStatus']);
    Route::patch('/orders/{order}/payment-status', [AdminOrderController::class, 'updatePaymentStatus']);
    Route::post('/orders/{order}/cancel', [AdminOrderController::class, 'cancel']);
    Route::post('/orders/{order}/refund', [AdminOrderController::class, 'refund']);
    
    // Invoices
    Route::get('/invoices', [InvoiceController::class, 'index']);
    Route::post('/invoices/{order}/generate', [InvoiceController::class, 'generate']);
    Route::post('/invoices/{invoice}/pdf', [InvoiceController::class, 'generatePDF']);
    Route::patch('/invoices/{invoice}/paid', [InvoiceController::class, 'markPaid']);
    Route::get('/invoices/{invoice}', [InvoiceController::class, 'show']);
    Route::get('/invoices/{invoice}/download', [InvoiceController::class, 'download']);
});
