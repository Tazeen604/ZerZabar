<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice {{ $invoice->invoice_number }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }
        .company-info {
            margin-bottom: 30px;
        }
        .invoice-details {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }
        .invoice-info, .customer-info {
            width: 48%;
        }
        .invoice-info h3, .customer-info h3 {
            margin-top: 0;
            color: #333;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .items-table th, .items-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        .items-table th {
            background-color: #f5f5f5;
            font-weight: bold;
        }
        .items-table .text-right {
            text-align: right;
        }
        .totals {
            width: 300px;
            margin-left: auto;
        }
        .totals table {
            width: 100%;
        }
        .totals td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        .totals .total-row {
            font-weight: bold;
            background-color: #f5f5f5;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .status-draft { background-color: #f0f0f0; color: #666; }
        .status-sent { background-color: #e3f2fd; color: #1976d2; }
        .status-paid { background-color: #e8f5e8; color: #2e7d32; }
        .status-overdue { background-color: #ffebee; color: #d32f2f; }
        .status-cancelled { background-color: #fafafa; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <h1>ZER ZABAR</h1>
        <h2>Gents E-commerce Store</h2>
        <p>Your Premium Fashion Destination</p>
    </div>

    <div class="invoice-details">
        <div class="invoice-info">
            <h3>Invoice Details</h3>
            <p><strong>Invoice Number:</strong> {{ $invoice->invoice_number }}</p>
            <p><strong>Issue Date:</strong> {{ \Carbon\Carbon::parse($invoice->issue_date)->format('M d, Y') }}</p>
            <p><strong>Due Date:</strong> {{ \Carbon\Carbon::parse($invoice->due_date)->format('M d, Y') }}</p>
            <p><strong>Status:</strong> 
                <span class="status-badge status-{{ $invoice->status }}">
                    {{ ucfirst($invoice->status) }}
                </span>
            </p>
        </div>

        <div class="customer-info">
            <h3>Bill To</h3>
            <p><strong>{{ $invoice->order->user->name }}</strong></p>
            <p>{{ $invoice->order->user->email }}</p>
            @if($invoice->order->billing_address)
                <p>{{ $invoice->order->billing_address['address'] ?? '' }}</p>
                <p>{{ $invoice->order->billing_address['city'] ?? '' }}, {{ $invoice->order->billing_address['state'] ?? '' }} {{ $invoice->order->billing_address['zip'] ?? '' }}</p>
                <p>{{ $invoice->order->billing_address['country'] ?? '' }}</p>
            @endif
        </div>
    </div>

    <table class="items-table">
        <thead>
            <tr>
                <th>Item</th>
                <th>SKU</th>
                <th class="text-right">Qty</th>
                <th class="text-right">Unit Price</th>
                <th class="text-right">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach($invoice->order->items as $item)
            <tr>
                <td>
                    <strong>{{ $item->product_name }}</strong>
                    @if($item->product_attributes)
                        <br><small>{{ implode(', ', array_map(function($key, $value) { return $key . ': ' . $value; }, array_keys($item->product_attributes), $item->product_attributes)) }}</small>
                    @endif
                </td>
                <td>{{ $item->product_sku }}</td>
                <td class="text-right">{{ $item->quantity }}</td>
                <td class="text-right">${{ number_format($item->unit_price, 2) }}</td>
                <td class="text-right">${{ number_format($item->total_price, 2) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="totals">
        <table>
            <tr>
                <td>Subtotal:</td>
                <td class="text-right">${{ number_format($invoice->subtotal, 2) }}</td>
            </tr>
            @if($invoice->tax_amount > 0)
            <tr>
                <td>Tax:</td>
                <td class="text-right">${{ number_format($invoice->tax_amount, 2) }}</td>
            </tr>
            @endif
            <tr class="total-row">
                <td><strong>Total:</strong></td>
                <td class="text-right"><strong>${{ number_format($invoice->total_amount, 2) }}</strong></td>
            </tr>
        </table>
    </div>

    @if($invoice->notes)
    <div style="margin-top: 30px;">
        <h3>Notes</h3>
        <p>{{ $invoice->notes }}</p>
    </div>
    @endif

    <div class="footer">
        <p>Thank you for your business!</p>
        <p>For any questions regarding this invoice, please contact us.</p>
        <p><strong>ZER ZABAR</strong> - Premium Gents Fashion</p>
    </div>
</body>
</html>











