<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */
class ProductFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $name = $this->faker->randomElement([
            'Classic White Shirt', 'Navy Blue Suit', 'Black Leather Shoes', 'Silk Tie', 'Wool Jacket',
            'Cotton Pants', 'Formal Blazer', 'Casual T-Shirt', 'Dress Shoes', 'Sports Jacket'
        ]);
        
        $price = $this->faker->randomFloat(2, 20, 500);
        $salePrice = $this->faker->boolean(30) ? $this->faker->randomFloat(2, 10, $price * 0.8) : null;
        
        return [
            'category_id' => \App\Models\Category::factory(),
            'name' => $name,
            'slug' => \Illuminate\Support\Str::slug($name),
            'description' => $this->faker->paragraph(3),
            'sku' => 'ZZ-' . $this->faker->unique()->numberBetween(1000, 9999),
            'price' => $price,
            'sale_price' => $salePrice,
            'stock_quantity' => $this->faker->numberBetween(0, 100),
            'stock_status' => $this->faker->randomElement(['in_stock', 'low_stock', 'out_of_stock']),
            'is_active' => $this->faker->boolean(85),
            'is_featured' => $this->faker->boolean(20),
            'attributes' => [
                'size' => $this->faker->randomElement(['S', 'M', 'L', 'XL', 'XXL']),
                'color' => $this->faker->colorName(),
                'material' => $this->faker->randomElement(['Cotton', 'Wool', 'Silk', 'Leather', 'Polyester']),
            ],
            'weight' => $this->faker->randomFloat(2, 0.1, 5.0),
            'dimensions' => $this->faker->randomElement(['30x20x5', '40x30x8', '35x25x6']),
        ];
    }
}
