<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->integer('stock_quantity')->default(0)->after('price');
            $table->integer('low_stock_threshold')->default(5)->after('stock_quantity');
            $table->boolean('track_stock')->default(true)->after('low_stock_threshold');
            $table->boolean('is_low_stock')->default(false)->after('track_stock');
            $table->decimal('cost_price', 10, 2)->nullable()->after('is_low_stock');
            $table->integer('total_sold')->default(0)->after('cost_price');
            $table->timestamp('last_sold_at')->nullable()->after('total_sold');
            
            $table->index(['is_low_stock', 'stock_quantity']);
            $table->index('total_sold');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn([
                'stock_quantity',
                'low_stock_threshold', 
                'track_stock',
                'is_low_stock',
                'cost_price',
                'total_sold',
                'last_sold_at'
            ]);
        });
    }
};