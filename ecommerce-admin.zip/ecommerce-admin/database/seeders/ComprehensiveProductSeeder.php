<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\Category;
use App\Models\Inventory;
use Illuminate\Support\Str;

class ComprehensiveProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = Category::all();
        
        $products = [
            // Shirts
            [
                'name' => 'Classic White Dress Shirt',
                'description' => 'Premium cotton dress shirt perfect for formal occasions',
                'sku' => 'ZZ-1001',
                'price' => 89.99,
                'sale_price' => 69.99,
                'stock_quantity' => 50,
                'category_id' => $categories->where('slug', 'shirts')->first()->id,
                'attributes' => ['size' => 'M', 'color' => 'White', 'material' => 'Cotton'],
                'is_featured' => true,
            ],
            [
                'name' => 'Blue Oxford Shirt',
                'description' => 'Comfortable blue oxford shirt for casual wear',
                'sku' => 'ZZ-1002',
                'price' => 79.99,
                'stock_quantity' => 45,
                'category_id' => $categories->where('slug', 'shirts')->first()->id,
                'attributes' => ['size' => 'L', 'color' => 'Blue', 'material' => 'Cotton'],
                'is_featured' => true,
            ],
            [
                'name' => 'Striped Business Shirt',
                'description' => 'Professional striped shirt for business meetings',
                'sku' => 'ZZ-1003',
                'price' => 95.99,
                'sale_price' => 75.99,
                'stock_quantity' => 30,
                'category_id' => $categories->where('slug', 'shirts')->first()->id,
                'attributes' => ['size' => 'M', 'color' => 'Blue/White', 'material' => 'Cotton'],
                'is_featured' => false,
            ],
            
            // Suits
            [
                'name' => 'Navy Blue Business Suit',
                'description' => 'Elegant navy blue suit for business and formal events',
                'sku' => 'ZZ-2001',
                'price' => 299.99,
                'stock_quantity' => 25,
                'category_id' => $categories->where('slug', 'suits')->first()->id,
                'attributes' => ['size' => 'L', 'color' => 'Navy Blue', 'material' => 'Wool'],
                'is_featured' => true,
            ],
            [
                'name' => 'Charcoal Gray Suit',
                'description' => 'Classic charcoal gray suit for professional occasions',
                'sku' => 'ZZ-2002',
                'price' => 349.99,
                'stock_quantity' => 20,
                'category_id' => $categories->where('slug', 'suits')->first()->id,
                'attributes' => ['size' => 'M', 'color' => 'Charcoal', 'material' => 'Wool'],
                'is_featured' => true,
            ],
            
            // Pants
            [
                'name' => 'Classic Dress Pants',
                'description' => 'Comfortable dress pants for office and formal wear',
                'sku' => 'ZZ-3001',
                'price' => 129.99,
                'stock_quantity' => 40,
                'category_id' => $categories->where('slug', 'pants')->first()->id,
                'attributes' => ['size' => '32', 'color' => 'Black', 'material' => 'Wool'],
                'is_featured' => false,
            ],
            [
                'name' => 'Khaki Chino Pants',
                'description' => 'Versatile khaki chino pants for casual and smart casual',
                'sku' => 'ZZ-3002',
                'price' => 89.99,
                'sale_price' => 69.99,
                'stock_quantity' => 35,
                'category_id' => $categories->where('slug', 'pants')->first()->id,
                'attributes' => ['size' => '34', 'color' => 'Khaki', 'material' => 'Cotton'],
                'is_featured' => true,
            ],
            
            // Jackets
            [
                'name' => 'Wool Blazer',
                'description' => 'Versatile wool blazer for smart casual looks',
                'sku' => 'ZZ-4001',
                'price' => 199.99,
                'sale_price' => 159.99,
                'stock_quantity' => 35,
                'category_id' => $categories->where('slug', 'jackets')->first()->id,
                'attributes' => ['size' => 'L', 'color' => 'Charcoal', 'material' => 'Wool'],
                'is_featured' => true,
            ],
            [
                'name' => 'Leather Jacket',
                'description' => 'Premium leather jacket for stylish casual wear',
                'sku' => 'ZZ-4002',
                'price' => 249.99,
                'stock_quantity' => 15,
                'category_id' => $categories->where('slug', 'jackets')->first()->id,
                'attributes' => ['size' => 'M', 'color' => 'Brown', 'material' => 'Leather'],
                'is_featured' => true,
            ],
            
            // Shoes
            [
                'name' => 'Black Leather Dress Shoes',
                'description' => 'Premium leather dress shoes for formal occasions',
                'sku' => 'ZZ-5001',
                'price' => 149.99,
                'stock_quantity' => 30,
                'category_id' => $categories->where('slug', 'shoes')->first()->id,
                'attributes' => ['size' => '10', 'color' => 'Black', 'material' => 'Leather'],
                'is_featured' => true,
            ],
            [
                'name' => 'Brown Oxford Shoes',
                'description' => 'Classic brown oxford shoes for business casual',
                'sku' => 'ZZ-5002',
                'price' => 129.99,
                'stock_quantity' => 25,
                'category_id' => $categories->where('slug', 'shoes')->first()->id,
                'attributes' => ['size' => '9', 'color' => 'Brown', 'material' => 'Leather'],
                'is_featured' => false,
            ],
            
            // Accessories
            [
                'name' => 'Silk Tie Collection',
                'description' => 'Luxurious silk ties in various patterns',
                'sku' => 'ZZ-6001',
                'price' => 49.99,
                'stock_quantity' => 40,
                'category_id' => $categories->where('slug', 'accessories')->first()->id,
                'attributes' => ['size' => 'One Size', 'color' => 'Multi', 'material' => 'Silk'],
                'is_featured' => false,
            ],
            [
                'name' => 'Leather Belt',
                'description' => 'Genuine leather belt for formal and casual wear',
                'sku' => 'ZZ-6002',
                'price' => 39.99,
                'stock_quantity' => 50,
                'category_id' => $categories->where('slug', 'accessories')->first()->id,
                'attributes' => ['size' => '32', 'color' => 'Black', 'material' => 'Leather'],
                'is_featured' => false,
            ],
        ];

        foreach ($products as $productData) {
            // Generate slug from name
            $productData['slug'] = Str::slug($productData['name']);
            $productData['is_active'] = 1; // Make products active
            $productData['stock_status'] = 'in_stock'; // Set stock status
            
            $product = Product::create($productData);
            
            // Create inventory record
            $product->inventory()->create([
                'quantity' => $productData['stock_quantity'],
                'cost_price' => $productData['price'] * 0.6, // 60% of selling price
            ]);
        }
    }
}


