<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = \App\Models\Category::all();
        
        $products = [
            [
                'name' => 'Classic White Dress Shirt',
                'description' => 'Premium cotton dress shirt perfect for formal occasions',
                'sku' => 'ZZ-1001',
                'price' => 89.99,
                'sale_price' => 69.99,
                'stock_quantity' => 50,
                'category_id' => $categories->where('slug', 'shirts')->first()->id,
                'attributes' => ['size' => 'M', 'color' => 'White', 'material' => 'Cotton'],
            ],
            [
                'name' => 'Navy Blue Business Suit',
                'description' => 'Elegant navy blue suit for business and formal events',
                'sku' => 'ZZ-1002',
                'price' => 299.99,
                'stock_quantity' => 25,
                'category_id' => $categories->where('slug', 'suits')->first()->id,
                'attributes' => ['size' => 'L', 'color' => 'Navy Blue', 'material' => 'Wool'],
            ],
            [
                'name' => 'Black Leather Dress Shoes',
                'description' => 'Premium leather dress shoes for formal occasions',
                'sku' => 'ZZ-1003',
                'price' => 149.99,
                'stock_quantity' => 30,
                'category_id' => $categories->where('slug', 'shoes')->first()->id,
                'attributes' => ['size' => '10', 'color' => 'Black', 'material' => 'Leather'],
            ],
            [
                'name' => 'Silk Tie Collection',
                'description' => 'Luxurious silk ties in various patterns',
                'sku' => 'ZZ-1004',
                'price' => 49.99,
                'stock_quantity' => 40,
                'category_id' => $categories->where('slug', 'accessories')->first()->id,
                'attributes' => ['size' => 'One Size', 'color' => 'Multi', 'material' => 'Silk'],
            ],
            [
                'name' => 'Wool Blazer',
                'description' => 'Versatile wool blazer for smart casual looks',
                'sku' => 'ZZ-1005',
                'price' => 199.99,
                'sale_price' => 159.99,
                'stock_quantity' => 35,
                'category_id' => $categories->where('slug', 'jackets')->first()->id,
                'attributes' => ['size' => 'L', 'color' => 'Charcoal', 'material' => 'Wool'],
            ],
        ];

        foreach ($products as $productData) {
            // Generate slug from name
            $productData['slug'] = \Illuminate\Support\Str::slug($productData['name']);
            $productData['is_active'] = 1; // Make products active
            $productData['stock_status'] = 'in_stock'; // Set stock status
            
            $product = \App\Models\Product::create($productData);
            
            // Create inventory record
            $product->inventory()->create([
                'quantity' => $productData['stock_quantity'],
                'cost_price' => $productData['price'] * 0.6, // 60% of selling price
            ]);
        }
    }
}
