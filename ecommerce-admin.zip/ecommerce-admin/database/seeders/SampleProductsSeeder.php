<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\ProductImage;
use App\Models\Inventory;
use Illuminate\Support\Str;

class SampleProductsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get existing categories
        $categories = Category::all();
        $subcategories = Subcategory::all();
        
        if ($categories->isEmpty() || $subcategories->isEmpty()) {
            $this->command->error('Please run the main seeders first to create categories and subcategories.');
            return;
        }

        $this->command->info('Creating 50 sample products...');

        // Sample product data
        $sampleProducts = [
            // Men's Clothing
            ['name' => 'Classic White T-Shirt', 'category' => 'T-Shirts', 'price' => 1200, 'sale_price' => 999, 'colors' => ['White', 'Black', 'Navy'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Denim Blue Jeans', 'category' => 'Pants', 'price' => 2500, 'sale_price' => 1999, 'colors' => ['Blue', 'Black'], 'sizes' => ['30', '32', '34', '36']],
            ['name' => 'Cotton Polo Shirt', 'category' => 'T-Shirts', 'price' => 1800, 'sale_price' => 1499, 'colors' => ['White', 'Blue', 'Red'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Cargo Pants', 'category' => 'Pants', 'price' => 2200, 'sale_price' => 1799, 'colors' => ['Khaki', 'Black', 'Olive'], 'sizes' => ['30', '32', '34', '36']],
            ['name' => 'Hoodie Sweatshirt', 'category' => 'Hoodies', 'price' => 3200, 'sale_price' => 2599, 'colors' => ['Gray', 'Black', 'Navy'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Leather Jacket', 'category' => 'Jacket', 'price' => 8500, 'sale_price' => 6999, 'colors' => ['Black', 'Brown'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Casual Button Shirt', 'category' => 'Shirts', 'price' => 2000, 'sale_price' => 1599, 'colors' => ['White', 'Blue', 'Pink'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Jogger Pants', 'category' => 'Pants', 'price' => 1800, 'sale_price' => 1399, 'colors' => ['Black', 'Gray', 'Navy'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Tank Top', 'category' => 'T-Shirts', 'price' => 800, 'sale_price' => 599, 'colors' => ['White', 'Black', 'Gray'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Chino Pants', 'category' => 'Pants', 'price' => 2400, 'sale_price' => 1999, 'colors' => ['Beige', 'Navy', 'Black'], 'sizes' => ['30', '32', '34', '36']],
            
            // Women's Clothing
            ['name' => 'Floral Summer Dress', 'category' => 'Dresses', 'price' => 3500, 'sale_price' => 2799, 'colors' => ['Pink', 'Blue', 'Yellow'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Skinny Jeans', 'category' => 'Pants', 'price' => 2800, 'sale_price' => 2299, 'colors' => ['Blue', 'Black', 'White'], 'sizes' => ['26', '28', '30', '32']],
            ['name' => 'Blouse Top', 'category' => 'Shirts', 'price' => 1600, 'sale_price' => 1299, 'colors' => ['White', 'Black', 'Red'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Maxi Dress', 'category' => 'Dresses', 'price' => 4200, 'sale_price' => 3399, 'colors' => ['Black', 'Navy', 'Red'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Crop Top', 'category' => 'T-Shirts', 'price' => 1000, 'sale_price' => 799, 'colors' => ['White', 'Black', 'Pink'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'High-Waist Shorts', 'category' => 'Shorts', 'price' => 1400, 'sale_price' => 1099, 'colors' => ['Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Wrap Dress', 'category' => 'Dresses', 'price' => 3800, 'sale_price' => 2999, 'colors' => ['Black', 'Navy', 'Red'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Oversized Sweater', 'category' => 'Sweater', 'price' => 2800, 'sale_price' => 2299, 'colors' => ['Beige', 'Gray', 'Black'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Midi Skirt', 'category' => 'Skirts', 'price' => 1800, 'sale_price' => 1399, 'colors' => ['Black', 'Navy', 'Pink'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Bodysuit', 'category' => 'T-Shirts', 'price' => 1200, 'sale_price' => 999, 'colors' => ['Black', 'White', 'Nude'], 'sizes' => ['XS', 'S', 'M', 'L']],
            
            // Accessories
            ['name' => 'Leather Belt', 'category' => 'Accessories', 'price' => 800, 'sale_price' => 599, 'colors' => ['Black', 'Brown'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Canvas Backpack', 'category' => 'Accessories', 'price' => 2500, 'sale_price' => 1999, 'colors' => ['Black', 'Navy', 'Khaki'], 'sizes' => ['One Size']],
            ['name' => 'Leather Wallet', 'category' => 'Accessories', 'price' => 1200, 'sale_price' => 999, 'colors' => ['Black', 'Brown'], 'sizes' => ['One Size']],
            ['name' => 'Baseball Cap', 'category' => 'Accessories', 'price' => 600, 'sale_price' => 499, 'colors' => ['Black', 'White', 'Navy'], 'sizes' => ['One Size']],
            ['name' => 'Sunglasses', 'category' => 'Accessories', 'price' => 1500, 'sale_price' => 1199, 'colors' => ['Black', 'Brown'], 'sizes' => ['One Size']],
            
            // More Men's Items
            ['name' => 'V-Neck T-Shirt', 'category' => 'T-Shirts', 'price' => 1000, 'sale_price' => 799, 'colors' => ['White', 'Black', 'Gray'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Rugby Shirt', 'category' => 'Shirts', 'price' => 2200, 'sale_price' => 1799, 'colors' => ['Blue', 'Red', 'Green'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Track Pants', 'category' => 'Pants', 'price' => 1600, 'sale_price' => 1299, 'colors' => ['Black', 'Gray', 'Navy'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Bomber Jacket', 'category' => 'Jacket', 'price' => 4500, 'sale_price' => 3699, 'colors' => ['Black', 'Navy', 'Olive'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Henley Shirt', 'category' => 'T-Shirts', 'price' => 1400, 'sale_price' => 1099, 'colors' => ['White', 'Black', 'Gray'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Cargo Shorts', 'category' => 'Shorts', 'price' => 1800, 'sale_price' => 1399, 'colors' => ['Khaki', 'Black', 'Olive'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Turtleneck Sweater', 'category' => 'Sweater', 'price' => 2600, 'sale_price' => 2099, 'colors' => ['Black', 'Gray', 'Navy'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Dress Shirt', 'category' => 'Shirts', 'price' => 2400, 'sale_price' => 1999, 'colors' => ['White', 'Blue', 'Pink'], 'sizes' => ['S', 'M', 'L', 'XL']],
            ['name' => 'Athletic Shorts', 'category' => 'Shorts', 'price' => 1200, 'sale_price' => 999, 'colors' => ['Black', 'Gray', 'Navy'], 'sizes' => ['S', 'M', 'L', 'XL']],
            
            // More Women's Items
            ['name' => 'A-Line Skirt', 'category' => 'Skirts', 'price' => 2000, 'sale_price' => 1599, 'colors' => ['Black', 'Navy', 'Pink'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Off-Shoulder Top', 'category' => 'T-Shirts', 'price' => 1400, 'sale_price' => 1099, 'colors' => ['White', 'Black', 'Pink'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Pencil Skirt', 'category' => 'Skirts', 'price' => 2200, 'sale_price' => 1799, 'colors' => ['Black', 'Navy', 'Gray'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Peplum Top', 'category' => 'Shirts', 'price' => 1800, 'sale_price' => 1399, 'colors' => ['White', 'Black', 'Red'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'A-Line Dress', 'category' => 'Dresses', 'price' => 3200, 'sale_price' => 2599, 'colors' => ['Black', 'Navy', 'Red'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Crop Hoodie', 'category' => 'Hoodies', 'price' => 2400, 'sale_price' => 1999, 'colors' => ['Gray', 'Black', 'Pink'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Pleated Skirt', 'category' => 'Skirts', 'price' => 1600, 'sale_price' => 1299, 'colors' => ['Black', 'Navy', 'Pink'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Tie-Front Top', 'category' => 'Shirts', 'price' => 1200, 'sale_price' => 999, 'colors' => ['White', 'Black', 'Blue'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Slip Dress', 'category' => 'Dresses', 'price' => 2800, 'sale_price' => 2299, 'colors' => ['Black', 'Navy', 'Red'], 'sizes' => ['XS', 'S', 'M', 'L']],
            ['name' => 'Oversized Blazer', 'category' => 'Jacket', 'price' => 4200, 'sale_price' => 3399, 'colors' => ['Black', 'Navy', 'Gray'], 'sizes' => ['XS', 'S', 'M', 'L']],
            
            // More Accessories
            ['name' => 'Crossbody Bag', 'category' => 'Accessories', 'price' => 1800, 'sale_price' => 1399, 'colors' => ['Black', 'Brown', 'Tan'], 'sizes' => ['One Size']],
            ['name' => 'Leather Watch', 'category' => 'Accessories', 'price' => 3500, 'sale_price' => 2799, 'colors' => ['Black', 'Brown'], 'sizes' => ['One Size']],
            ['name' => 'Scarf', 'category' => 'Accessories', 'price' => 800, 'sale_price' => 599, 'colors' => ['Black', 'Red', 'Blue'], 'sizes' => ['One Size']],
            ['name' => 'Phone Case', 'category' => 'Accessories', 'price' => 400, 'sale_price' => 299, 'colors' => ['Black', 'White', 'Transparent'], 'sizes' => ['One Size']],
            ['name' => 'Keychain', 'category' => 'Accessories', 'price' => 200, 'sale_price' => 149, 'colors' => ['Black', 'Silver', 'Gold'], 'sizes' => ['One Size']],
        ];

        foreach ($sampleProducts as $index => $productData) {
            // Find category
            $category = $categories->where('name', $productData['category'])->first();
            if (!$category) {
                $category = $categories->first(); // Fallback to first category
            }

            // Find subcategory
            $subcategory = $subcategories->where('category_id', $category->id)->first();
            if (!$subcategory) {
                $subcategory = $subcategories->first(); // Fallback to first subcategory
            }

            // Create product
            $product = Product::create([
                'product_id' => 'SAMPLE-' . str_pad($index + 1, 4, '0', STR_PAD_LEFT),
                'category_id' => $category->id,
                'subcategory_id' => $subcategory->id,
                'name' => $productData['name'],
                'slug' => Str::slug($productData['name']) . '-' . ($index + 1),
                'description' => 'High-quality ' . strtolower($productData['name']) . ' made from premium materials. Perfect for everyday wear with comfort and style.',
                'sku' => 'SAMPLE-' . str_pad($index + 1, 4, '0', STR_PAD_LEFT),
                'price' => $productData['price'],
                'sale_price' => $productData['sale_price'],
                'stock_quantity' => rand(10, 100),
                'stock_status' => 'in_stock',
                'is_active' => true,
                'is_featured' => rand(0, 1) == 1,
                'attributes' => json_encode([
                    'material' => ['Cotton', 'Polyester', 'Leather'][rand(0, 2)],
                    'care_instructions' => 'Machine wash cold, tumble dry low',
                ]),
                'sizes' => json_encode($productData['sizes']),
                'colors' => json_encode($productData['colors']),
                'weight' => rand(100, 1000),
                'dimensions' => json_encode([
                    'length' => rand(60, 120) . 'cm',
                    'width' => rand(40, 80) . 'cm',
                ]),
            ]);

            // Create inventory record
            Inventory::create([
                'product_id' => $product->id,
                'quantity' => $product->stock_quantity,
                'reserved_quantity' => 0,
                'cost_price' => $product->price * 0.6, // 60% of selling price
                'location' => 'Main Warehouse',
            ]);

            // Create sample images (using placeholder)
            ProductImage::create([
                'product_id' => $product->id,
                'image_path' => 'products/sample-product-' . ($index + 1) . '.jpg',
                'alt_text' => $product->name,
                'is_primary' => true,
                'sort_order' => 0,
            ]);

            // Add secondary image
            if (rand(0, 1)) {
                ProductImage::create([
                    'product_id' => $product->id,
                    'image_path' => 'products/sample-product-' . ($index + 1) . '-2.jpg',
                    'alt_text' => $product->name . ' - View 2',
                    'is_primary' => false,
                    'sort_order' => 1,
                ]);
            }
        }

        $this->command->info('Successfully created 50 sample products!');
        $this->command->info('These products can be easily removed by running: php artisan db:seed --class=RemoveSampleProductsSeeder');
    }
}