<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Support\Str;

class CategorySubcategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Define categories and their subcategories
        $categoriesData = [
            [
                'name' => 'Pants',
                'subcategories' => ['Denim Pants', 'Cotton Pants']
            ],
            [
                'name' => 'Shirts',
                'subcategories' => ['Casual Shirts']
            ],
            [
                'name' => 'T-Shirts',
                'subcategories' => ['Polo Tee', 'Drop Shoulder Tee', 'Plain Tee']
            ],
            [
                'name' => 'Shorts',
                'subcategories' => ['Cotton Nicker', 'Denim Nicker']
            ],
            [
                'name' => 'Jacket',
                'subcategories' => ['Sleeveless Jacket', 'Puffer Jacket']
            ],
            [
                'name' => 'Sweat Shirt',
                'subcategories' => []
            ],
            [
                'name' => 'Casual Coat',
                'subcategories' => []
            ],
            [
                'name' => 'Hoodies',
                'subcategories' => []
            ],
            [
                'name' => 'Sweater Zipper',
                'subcategories' => []
            ],
            [
                'name' => 'Accessories',
                'subcategories' => ['Watches', 'Belts', 'Wallets', 'Bags']
            ]
        ];

        foreach ($categoriesData as $index => $categoryData) {
            // Create or update category
            $category = Category::updateOrCreate(
                ['slug' => Str::slug($categoryData['name'])],
                [
                    'name' => $categoryData['name'],
                    'description' => 'Premium quality ' . $categoryData['name'] . ' collection',
                    'is_active' => true,
                    'sort_order' => $index + 1,
                ]
            );

            // Delete existing subcategories for this category
            Subcategory::where('category_id', $category->id)->delete();

            // Create subcategories
            foreach ($categoryData['subcategories'] as $subIndex => $subcategoryName) {
                Subcategory::create([
                    'name' => $subcategoryName,
                    'slug' => Str::slug($subcategoryName),
                    'description' => 'High-quality ' . $subcategoryName,
                    'category_id' => $category->id,
                    'is_active' => true,
                    'sort_order' => $subIndex + 1,
                ]);
            }
        }

        $this->command->info('Categories and subcategories seeded successfully!');
    }
}