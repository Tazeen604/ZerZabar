<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Clear existing categories first
        Category::query()->delete();
        
        $categories = [
            [
                'name' => 'Pants',
                'slug' => 'pants',
                'description' => 'Comfortable and stylish pants for men',
                'is_active' => true,
                'children' => [
                    [
                        'name' => 'Denim Pants',
                        'slug' => 'denim-pants',
                        'description' => 'Classic denim pants in various fits',
                        'is_active' => true,
                    ],
                    [
                        'name' => 'Cotton Pants',
                        'slug' => 'cotton-pants',
                        'description' => 'Comfortable cotton pants for everyday wear',
                        'is_active' => true,
                    ],
                ]
            ],
            [
                'name' => 'Shirts',
                'slug' => 'shirts',
                'description' => 'Professional and casual shirts',
                'is_active' => true,
                'children' => [
                    [
                        'name' => 'Casual Shirts',
                        'slug' => 'casual-shirts',
                        'description' => 'Comfortable casual shirts for everyday wear',
                        'is_active' => true,
                    ],
                ]
            ],
            [
                'name' => 'T-Shirts',
                'slug' => 't-shirts',
                'description' => 'Comfortable t-shirts for casual wear',
                'is_active' => true,
                'children' => [
                    [
                        'name' => 'Polo Tee',
                        'slug' => 'polo-tee',
                        'description' => 'Classic polo t-shirts',
                        'is_active' => true,
                    ],
                    [
                        'name' => 'Drop Shoulder Tee',
                        'slug' => 'drop-shoulder-tee',
                        'description' => 'Trendy drop shoulder t-shirts',
                        'is_active' => true,
                    ],
                    [
                        'name' => 'Plain Tee',
                        'slug' => 'plain-tee',
                        'description' => 'Simple and comfortable plain t-shirts',
                        'is_active' => true,
                    ],
                ]
            ],
            [
                'name' => 'Shorts',
                'slug' => 'shorts',
                'description' => 'Comfortable shorts for summer',
                'is_active' => true,
                'children' => [
                    [
                        'name' => 'Cotton Shorts',
                        'slug' => 'cotton-shorts',
                        'description' => 'Comfortable cotton shorts',
                        'is_active' => true,
                    ],
                    [
                        'name' => 'Denim Shorts',
                        'slug' => 'denim-shorts',
                        'description' => 'Classic denim shorts',
                        'is_active' => true,
                    ],
                ]
            ],
            [
                'name' => 'Jackets',
                'slug' => 'jackets',
                'description' => 'Stylish jackets for all seasons',
                'is_active' => true,
                'children' => [
                    [
                        'name' => 'Sleeveless Jacket',
                        'slug' => 'sleeveless-jacket',
                        'description' => 'Trendy sleeveless jackets',
                        'is_active' => true,
                    ],
                    [
                        'name' => 'Puffer Jacket',
                        'slug' => 'puffer-jacket',
                        'description' => 'Warm and stylish puffer jackets',
                        'is_active' => true,
                    ],
                ]
            ],
            [
                'name' => 'Sweatshirts',
                'slug' => 'sweatshirts',
                'description' => 'Comfortable sweatshirts for casual wear',
                'is_active' => true,
            ],
            [
                'name' => 'Casual Coats',
                'slug' => 'casual-coats',
                'description' => 'Stylish casual coats',
                'is_active' => true,
            ],
            [
                'name' => 'Hoodies',
                'slug' => 'hoodies',
                'description' => 'Comfortable hoodies for casual wear',
                'is_active' => true,
            ],
            [
                'name' => 'Sweater Zippers',
                'slug' => 'sweater-zippers',
                'description' => 'Warm sweater zippers',
                'is_active' => true,
            ],
            [
                'name' => 'Accessories',
                'slug' => 'accessories',
                'description' => 'Fashion accessories for men',
                'is_active' => true,
            ],
        ];

        foreach ($categories as $categoryData) {
            $children = $categoryData['children'] ?? [];
            unset($categoryData['children']);
            
            try {
                $category = Category::create($categoryData);
                
                // Create child categories
                foreach ($children as $childData) {
                    try {
                        Category::create([
                            ...$childData,
                            'parent_id' => $category->id,
                        ]);
                    } catch (\Exception $e) {
                        echo "Error creating child category {$childData['name']}: " . $e->getMessage() . "\n";
                    }
                }
            } catch (\Exception $e) {
                echo "Error creating category {$categoryData['name']}: " . $e->getMessage() . "\n";
            }
        }
    }
}