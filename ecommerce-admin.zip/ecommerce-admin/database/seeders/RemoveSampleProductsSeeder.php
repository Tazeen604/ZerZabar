<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Inventory;
use Illuminate\Support\Facades\DB;

class RemoveSampleProductsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->command->info('Removing sample products...');

        // Get all sample products (those with product_id starting with 'SAMPLE-')
        $sampleProducts = Product::where('product_id', 'like', 'SAMPLE-%')->get();
        
        if ($sampleProducts->isEmpty()) {
            $this->command->info('No sample products found to remove.');
            return;
        }

        $this->command->info('Found ' . $sampleProducts->count() . ' sample products to remove.');

        // Delete related records first
        foreach ($sampleProducts as $product) {
            // Delete product images
            ProductImage::where('product_id', $product->id)->delete();
            
            // Delete inventory records
            Inventory::where('product_id', $product->id)->delete();
            
            // Delete the product
            $product->delete();
        }

        $this->command->info('Successfully removed all sample products!');
        $this->command->info('Removed ' . $sampleProducts->count() . ' products and their related records.');
    }
}