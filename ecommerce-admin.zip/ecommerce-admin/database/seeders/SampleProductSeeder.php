<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Inventory;
use Illuminate\Support\Str;

class SampleProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get some categories
        $pantsCategory = Category::where('name', 'Pants')->first();
        $shirtsCategory = Category::where('name', 'Shirts')->first();
        $tshirtsCategory = Category::where('name', 'T-Shirts')->first();

        if (!$pantsCategory || !$shirtsCategory || !$tshirtsCategory) {
            $this->command->error('Categories not found. Please run CategorySubcategorySeeder first.');
            return;
        }

        // Sample products data
        $products = [
            [
                'product_id' => 'zz-prd-0001',
                'name' => 'Classic Blue Jeans',
                'description' => 'Premium quality denim jeans with comfortable fit and modern style.',
                'category_id' => $pantsCategory->id,
                'subcategory_id' => $pantsCategory->subcategories()->where('name', 'Denim Pants')->first()?->id,
                'sku' => 'JEANS-001',
                'price' => 2999.99,
                'sale_price' => 2499.99,
                'stock_quantity' => 50,
                'sizes' => json_encode(['30', '32', '34', '36', '38']),
                'colors' => json_encode(['Blue', 'Black', 'Dark Blue']),
                'weight' => 0.8,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'product_id' => 'zz-prd-0002',
                'name' => 'Cotton Casual Shirt',
                'description' => 'Comfortable cotton shirt perfect for casual and office wear.',
                'category_id' => $shirtsCategory->id,
                'subcategory_id' => $shirtsCategory->subcategories()->where('name', 'Casual Shirts')->first()?->id,
                'sku' => 'SHIRT-001',
                'price' => 1999.99,
                'sale_price' => null,
                'stock_quantity' => 30,
                'sizes' => json_encode(['S', 'M', 'L', 'XL', 'XXL']),
                'colors' => json_encode(['White', 'Blue', 'Black', 'Gray']),
                'weight' => 0.3,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'product_id' => 'zz-prd-0003',
                'name' => 'Premium Polo T-Shirt',
                'description' => 'High-quality polo t-shirt with premium fabric and elegant design.',
                'category_id' => $tshirtsCategory->id,
                'subcategory_id' => $tshirtsCategory->subcategories()->where('name', 'Polo Tee')->first()?->id,
                'sku' => 'POLO-001',
                'price' => 1499.99,
                'sale_price' => 1299.99,
                'stock_quantity' => 75,
                'sizes' => json_encode(['S', 'M', 'L', 'XL']),
                'colors' => json_encode(['Red', 'Navy', 'White', 'Green']),
                'weight' => 0.2,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'product_id' => 'zz-prd-0004',
                'name' => 'Plain Cotton T-Shirt',
                'description' => 'Simple and comfortable cotton t-shirt for everyday wear.',
                'category_id' => $tshirtsCategory->id,
                'subcategory_id' => $tshirtsCategory->subcategories()->where('name', 'Plain Tee')->first()?->id,
                'sku' => 'TEE-001',
                'price' => 899.99,
                'sale_price' => null,
                'stock_quantity' => 5, // Low stock for testing
                'sizes' => json_encode(['S', 'M', 'L', 'XL', 'XXL']),
                'colors' => json_encode(['Black', 'White', 'Gray', 'Navy']),
                'weight' => 0.15,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'product_id' => 'zz-prd-0005',
                'name' => 'Chino Pants',
                'description' => 'Stylish chino pants perfect for smart casual occasions.',
                'category_id' => $pantsCategory->id,
                'subcategory_id' => $pantsCategory->subcategories()->where('name', 'Cotton Pants')->first()?->id,
                'sku' => 'CHINO-001',
                'price' => 2499.99,
                'sale_price' => 1999.99,
                'stock_quantity' => 0, // Out of stock for testing
                'sizes' => json_encode(['30', '32', '34', '36', '38', '40']),
                'colors' => json_encode(['Khaki', 'Navy', 'Black', 'Olive']),
                'weight' => 0.6,
                'is_active' => true,
                'is_featured' => false,
            ],
        ];

        foreach ($products as $productData) {
            $productData['slug'] = Str::slug($productData['name']);
            $productData['stock_status'] = $productData['stock_quantity'] > 0 ? 'in_stock' : 'out_of_stock';
            
            $product = Product::create($productData);

            // Create inventory record
            Inventory::create([
                'product_id' => $product->id,
                'quantity' => $productData['stock_quantity'],
                'reserved_quantity' => 0,
                'cost_price' => $productData['price'] * 0.6, // 60% of selling price as cost
                'location' => 'Main Warehouse',
            ]);
        }

        $this->command->info('Sample products created successfully!');
    }
}