# Zer Zabar E-commerce Backend

A complete Laravel backend for a gents e-commerce site with admin panel APIs.

## Features

- **Authentication**: Laravel Sanctum for API authentication
- **User Management**: Admin and customer roles
- **Product Management**: Full CRUD with images, categories, inventory
- **Order Management**: Complete order lifecycle with status tracking
- **Inventory Management**: Stock tracking with history
- **Invoice Generation**: PDF invoice generation with DomPDF
- **Reports**: Sales, inventory, and order reports
- **Admin APIs**: Comprehensive admin panel endpoints

## Setup Instructions

### 1. Environment Configuration

Update your `.env` file with the following database settings:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=zerZabar_b
DB_USERNAME=root
DB_PASSWORD=
```

### 2. Install Dependencies

```bash
composer install
```

### 3. Install Required Packages

```bash
composer require barryvdh/laravel-dompdf
```

### 4. Generate Application Key

```bash
php artisan key:generate
```

### 5. Create Storage Link

```bash
php artisan storage:link
```

### 6. Run Migrations

```bash
php artisan migrate
```

### 7. Seed Database

```bash
php artisan db:seed
```

### 8. Start Development Server

```bash
php artisan serve
```

## API Endpoints

### Authentication
- `POST /api/admin/login` - Admin login
- `POST /api/admin/logout` - Admin logout
- `GET /api/admin/me` - Get current user

### Dashboard & Reports
- `GET /api/admin/dashboard` - Dashboard statistics
- `GET /api/admin/reports/sales` - Sales report
- `GET /api/admin/reports/inventory` - Inventory report
- `GET /api/admin/reports/orders` - Orders report

### Categories
- `GET /api/admin/categories` - List categories
- `POST /api/admin/categories` - Create category
- `GET /api/admin/categories/{id}` - Show category
- `PUT /api/admin/categories/{id}` - Update category
- `DELETE /api/admin/categories/{id}` - Delete category

### Products
- `GET /api/admin/products` - List products
- `POST /api/admin/products` - Create product
- `GET /api/admin/products/{id}` - Show product
- `PUT /api/admin/products/{id}` - Update product
- `DELETE /api/admin/products/{id}` - Delete product

### Inventory
- `GET /api/admin/inventory` - List inventory
- `GET /api/admin/inventory/low-stock` - Low stock report
- `POST /api/admin/inventory/{product}/adjust` - Adjust stock
- `GET /api/admin/inventory/{product}/history` - Stock history

### Orders
- `GET /api/admin/orders` - List orders
- `GET /api/admin/orders/{id}` - Show order
- `PATCH /api/admin/orders/{id}/status` - Update order status
- `PATCH /api/admin/orders/{id}/payment-status` - Update payment status
- `POST /api/admin/orders/{id}/cancel` - Cancel order
- `POST /api/admin/orders/{id}/refund` - Refund order

### Invoices
- `GET /api/admin/invoices` - List invoices
- `POST /api/admin/invoices/{order}/generate` - Generate invoice
- `POST /api/admin/invoices/{id}/pdf` - Generate PDF
- `PATCH /api/admin/invoices/{id}/paid` - Mark as paid
- `GET /api/admin/invoices/{id}` - Show invoice
- `GET /api/admin/invoices/{id}/download` - Download PDF

## Default Admin Credentials

- **Email**: admin@zerzabar.com
- **Password**: password

## Database Structure

### Tables
- `users` - Admin and customer users
- `categories` - Product categories
- `products` - Product information
- `product_images` - Product images
- `inventory` - Stock quantities
- `inventory_history` - Stock change history
- `orders` - Customer orders
- `order_items` - Order line items
- `invoices` - Generated invoices

### Relationships
- Category → Products (1:many)
- Product → Images (1:many)
- Product → Inventory (1:1)
- Product → OrderItems (1:many)
- Order → OrderItems (1:many)
- Order → Invoice (1:1)
- User → Orders (1:many)

## API Response Format

All API responses follow this consistent format:

```json
{
    "success": true,
    "data": {},
    "message": "Success message"
}
```

## File Storage

- Product images: `storage/app/public/products/`
- Category images: `storage/app/public/categories/`
- Invoice PDFs: `storage/app/public/invoices/`

## Features Implemented

✅ **Authentication System**
- Laravel Sanctum integration
- Admin role-based access
- Secure token management

✅ **Product Management**
- Full CRUD operations
- Image upload support
- Category relationships
- SKU management
- Stock tracking

✅ **Inventory Management**
- Real-time stock tracking
- Inventory history logging
- Low stock alerts
- Stock adjustment with reasons

✅ **Order Management**
- Complete order lifecycle
- Status tracking
- Payment status management
- Order cancellation and refunds

✅ **Invoice System**
- PDF generation with DomPDF
- Professional invoice templates
- Payment tracking
- Download functionality

✅ **Reporting System**
- Sales analytics
- Inventory reports
- Order statistics
- Dashboard metrics

✅ **Admin Panel APIs**
- Comprehensive CRUD endpoints
- Search and filtering
- Pagination support
- Consistent JSON responses

## Testing the API

You can test the API using tools like Postman or curl:

```bash
# Login
curl -X POST http://localhost:8000/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@zerzabar.com","password":"password"}'

# Get products (with token)
curl -X GET http://localhost:8000/api/admin/products \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## Next Steps

1. Run the setup commands above
2. Test the API endpoints
3. Integrate with your frontend admin panel
4. Customize the invoice template if needed
5. Add additional business logic as required

The backend is now ready to support your gents e-commerce frontend!