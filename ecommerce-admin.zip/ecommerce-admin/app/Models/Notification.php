<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $fillable = [
        'type',
        'title',
        'message',
        'data',
        'read',
        'read_at'
    ];

    protected $casts = [
        'data' => 'array',
        'read' => 'boolean',
        'read_at' => 'datetime',
    ];

    /**
     * Mark notification as read
     */
    public function markAsRead()
    {
        $this->update([
            'read' => true,
            'read_at' => now()
        ]);
    }

    /**
     * Create a low stock notification
     */
    public static function createLowStockNotification($product)
    {
        return static::create([
            'type' => 'low_stock',
            'title' => 'Low Stock Alert',
            'message' => "Product '{$product->name}' is running low on stock. Current quantity: {$product->stock_quantity}",
            'data' => [
                'product_id' => $product->id,
                'product_name' => $product->name,
                'stock_quantity' => $product->stock_quantity,
                'low_stock_threshold' => $product->low_stock_threshold ?? 10
            ]
        ]);
    }

    /**
     * Get unread notifications count
     */
    public static function getUnreadCount()
    {
        return static::where('read', false)->count();
    }

    /**
     * Mark all notifications as read
     */
    public static function markAllAsRead()
    {
        return static::where('read', false)->update([
            'read' => true,
            'read_at' => now()
        ]);
    }
}
