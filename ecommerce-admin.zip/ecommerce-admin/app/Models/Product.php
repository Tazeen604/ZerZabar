<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\Schema;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_id',
        'category_id',
        'subcategory_id',
        'name',
        'slug',
        'description',
        'sku',
        'price',
        'sale_price',
        'stock_quantity',
        'low_stock_threshold',
        'track_stock',
        'is_low_stock',
        'cost_price',
        'total_sold',
        'last_sold_at',
        'stock_status',
        'is_active',
        'is_featured',
        'attributes',
        'sizes',
        'colors',
        'weight',
        'dimensions',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_featured' => 'boolean',
        'track_stock' => 'boolean',
        'is_low_stock' => 'boolean',
        'attributes' => 'array',
        'sizes' => 'array',
        'colors' => 'array',
        'price' => 'decimal:2',
        'sale_price' => 'decimal:2',
        'cost_price' => 'decimal:2',
        'weight' => 'decimal:2',
        'last_sold_at' => 'datetime',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function subcategory(): BelongsTo
    {
        return $this->belongsTo(Subcategory::class);
    }

    public function images(): HasMany
    {
        return $this->hasMany(ProductImage::class);
    }

    public function primaryImage(): HasOne
    {
        return $this->hasOne(ProductImage::class)->where('is_primary', true);
    }

    public function inventory(): HasOne
    {
        return $this->hasOne(Inventory::class);
    }

    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function inventoryHistory(): HasMany
    {
        return $this->hasMany(InventoryHistory::class);
    }

    // Inventory management methods
    public function updateStock(int $quantity, string $type = 'sale'): void
    {
        if (!$this->track_stock) {
            return;
        }

        $oldStock = $this->stock_quantity;
        
        if ($type === 'sale') {
            $this->stock_quantity = max(0, $this->stock_quantity - $quantity);
            $this->total_sold += $quantity;
            $this->last_sold_at = now();
        } else {
            $this->stock_quantity += $quantity;
        }

        $this->save();

        // Update low stock status
        $this->updateLowStockStatus();

        // Create inventory history record
        $this->inventoryHistory()->create([
            'type' => 'adjustment', // Use valid enum value
            'quantity_change' => $quantity,
            'quantity_before' => $oldStock,
            'quantity_after' => $this->stock_quantity,
            'reason' => $type === 'sale' ? 'Stock reduced due to sale' : 'Stock manually adjusted',
        ]);
    }

    public function updateLowStockStatus(): void
    {
        $threshold = $this->low_stock_threshold ?? 10; // Use default threshold if not set
        $isLowStock = $this->stock_quantity <= $threshold;
        
        // Only update is_low_stock column if it exists in the database
        if (Schema::hasColumn('products', 'is_low_stock')) {
            $this->is_low_stock = $isLowStock;
            $this->save();
        }
    }

    public function isLowStock(): bool
    {
        $threshold = $this->low_stock_threshold ?? 10; // Use default threshold if not set
        return $this->stock_quantity <= $threshold;
    }

    public function getStockStatusBadgeClass(): string
    {
        if ($this->stock_quantity <= 0) {
            return 'bg-red-100 text-red-800';
        } elseif ($this->isLowStock()) {
            return 'bg-yellow-100 text-yellow-800';
        } else {
            return 'bg-green-100 text-green-800';
        }
    }

    public function getStockStatusText(): string
    {
        if ($this->stock_quantity <= 0) {
            return 'Out of Stock';
        } elseif ($this->isLowStock()) {
            return 'Low Stock';
        } else {
            return 'In Stock';
        }
    }
}
