<?php

namespace App\Http\Controllers;

use App\Models\Subcategory;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class SubcategoryController extends Controller
{
    /**
     * Display a listing of subcategories.
     */
    public function index(Request $request): JsonResponse
    {
        $query = Subcategory::with('category');

        // Filter by category if provided
        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        // Search functionality
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        // Filter by status
        if ($request->has('is_active')) {
            $query->where('is_active', $request->boolean('is_active'));
        }

        $subcategories = $query->orderBy('sort_order')->orderBy('name')->get();

        return response()->json([
            'success' => true,
            'data' => $subcategories
        ]);
    }

    /**
     * Store a newly created subcategory.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'category_id' => 'required|exists:categories,id',
            'image' => 'nullable|string',
            'is_active' => 'boolean',
            'sort_order' => 'integer|min:0',
        ]);

        // Generate slug from name
        $validated['slug'] = Str::slug($validated['name']);
        
        // Ensure slug is unique
        $originalSlug = $validated['slug'];
        $counter = 1;
        while (Subcategory::where('slug', $validated['slug'])->exists()) {
            $validated['slug'] = $originalSlug . '-' . $counter;
            $counter++;
        }

        $subcategory = Subcategory::create($validated);
        $subcategory->load('category');

        return response()->json([
            'success' => true,
            'message' => 'Subcategory created successfully',
            'data' => $subcategory
        ], 201);
    }

    /**
     * Display the specified subcategory.
     */
    public function show(Subcategory $subcategory): JsonResponse
    {
        $subcategory->load('category', 'products');

        return response()->json([
            'success' => true,
            'data' => $subcategory
        ]);
    }

    /**
     * Update the specified subcategory.
     */
    public function update(Request $request, Subcategory $subcategory): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'category_id' => 'required|exists:categories,id',
            'image' => 'nullable|string',
            'is_active' => 'boolean',
            'sort_order' => 'integer|min:0',
        ]);

        // Generate slug from name if name changed
        if ($validated['name'] !== $subcategory->name) {
            $validated['slug'] = Str::slug($validated['name']);
            
            // Ensure slug is unique (excluding current subcategory)
            $originalSlug = $validated['slug'];
            $counter = 1;
            while (Subcategory::where('slug', $validated['slug'])->where('id', '!=', $subcategory->id)->exists()) {
                $validated['slug'] = $originalSlug . '-' . $counter;
                $counter++;
            }
        }

        $subcategory->update($validated);
        $subcategory->load('category');

        return response()->json([
            'success' => true,
            'message' => 'Subcategory updated successfully',
            'data' => $subcategory
        ]);
    }

    /**
     * Remove the specified subcategory.
     */
    public function destroy(Subcategory $subcategory): JsonResponse
    {
        // Check if subcategory has products
        if ($subcategory->products()->count() > 0) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot delete subcategory. It has associated products.'
            ], 422);
        }

        $subcategory->delete();

        return response()->json([
            'success' => true,
            'message' => 'Subcategory deleted successfully'
        ]);
    }

    /**
     * Get subcategories by category
     */
    public function getByCategory(Category $category): JsonResponse
    {
        $subcategories = $category->subcategories()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $subcategories
        ]);
    }

    /**
     * Toggle subcategory status
     */
    public function toggleStatus(Subcategory $subcategory): JsonResponse
    {
        $subcategory->update([
            'is_active' => !$subcategory->is_active
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Subcategory status updated successfully',
            'data' => $subcategory
        ]);
    }
}