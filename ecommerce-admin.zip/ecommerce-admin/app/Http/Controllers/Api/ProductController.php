<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Product::with(['category', 'images', 'inventory'])
            ->where('is_active', 1);

        // Search
        if ($request->has('search') && $request->get('search') !== '') {
            $search = $request->get('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        // Filter by category
        if ($request->has('category_id') && $request->get('category_id') !== '') {
            $categoryId = $request->get('category_id');
            \Log::info('Filtering by category_id:', ['category_id' => $categoryId, 'type' => gettype($categoryId)]);
            $query->where('category_id', $categoryId);
        } else {
            \Log::info('No category filter applied - showing all products');
        }

        // Filter by price range
        if ($request->has('min_price') && $request->get('min_price') !== '') {
            $query->where('price', '>=', $request->get('min_price'));
        }

        if ($request->has('max_price') && $request->get('max_price') !== '') {
            $query->where('price', '<=', $request->get('max_price'));
        }

        // Filter by stock status
        if ($request->has('in_stock')) {
            $query->where('stock_status', 'in_stock');
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'created_at');
        $sortOrder = $request->get('sort_order', 'desc');
        
        if (in_array($sortBy, ['name', 'price', 'created_at'])) {
            $query->orderBy($sortBy, $sortOrder);
        }

        $products = $query->paginate($request->get('per_page', 12));
        
        \Log::info('Products query result:', [
            'total_products' => $products->total(),
            'count' => $products->count(),
            'current_page' => $products->currentPage(),
            'per_page' => $products->perPage(),
            'has_category_filter' => $request->has('category_id') && $request->get('category_id') !== '',
            'category_id' => $request->get('category_id')
        ]);

        return response()->json([
            'success' => true,
            'data' => $products,
            'message' => 'Products retrieved successfully',
        ]);
    }

    public function show(Product $product): JsonResponse
    {
        if ($product->is_active != 1) {
            return response()->json([
                'success' => false,
                'message' => 'Product not found',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $product->load(['category', 'images', 'inventory']),
            'message' => 'Product retrieved successfully',
        ]);
    }

    public function featured(): JsonResponse
    {
        $products = Product::with(['category', 'images', 'inventory'])
            ->where('is_active', 1)
            ->where('is_featured', 1)
            ->where('stock_status', 'in_stock')
            ->orderBy('created_at', 'desc')
            ->limit(8)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $products,
            'message' => 'Featured products retrieved successfully',
        ]);
    }

    public function newArrivals(): JsonResponse
    {
        $products = Product::with(['category', 'images', 'inventory'])
            ->where('is_active', 1)
            ->where('stock_status', 'in_stock')
            ->orderBy('created_at', 'desc')
            ->limit(8)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $products,
            'message' => 'New arrivals retrieved successfully',
        ]);
    }

    public function carousel(): JsonResponse
    {
        $products = Product::with(['category', 'images', 'inventory'])
            ->where('is_active', 1)
            ->where('stock_status', 'in_stock')
            ->orderBy('created_at', 'desc')
            ->limit(6)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $products,
            'message' => 'Carousel products retrieved successfully',
        ]);
    }
}
