<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class CartController extends Controller
{
    public function calculate(Request $request): JsonResponse
    {
        $request->validate([
            'items' => 'required|array',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
        ]);

        $subtotal = 0;
        $items = [];

        foreach ($request->items as $item) {
            $product = Product::findOrFail($item['product_id']);
            
            if (!$product->is_active || $product->stock_status === 'out_of_stock') {
                return response()->json([
                    'success' => false,
                    'message' => "Product {$product->name} is not available",
                ], 422);
            }

            if ($product->stock_quantity < $item['quantity']) {
                return response()->json([
                    'success' => false,
                    'message' => "Insufficient stock for {$product->name}",
                ], 422);
            }

            $unitPrice = $product->sale_price ?? $product->price;
            $totalPrice = $unitPrice * $item['quantity'];
            $subtotal += $totalPrice;

            $items[] = [
                'product_id' => $product->id,
                'product_name' => $product->name,
                'product_sku' => $product->sku,
                'quantity' => $item['quantity'],
                'unit_price' => $unitPrice,
                'total_price' => $totalPrice,
            ];
        }

        $taxAmount = $subtotal * 0.1; // 10% tax
        $shippingAmount = 10.00; // Fixed shipping
        $totalAmount = $subtotal + $taxAmount + $shippingAmount;

        return response()->json([
            'success' => true,
            'data' => [
                'items' => $items,
                'subtotal' => $subtotal,
                'tax_amount' => $taxAmount,
                'shipping_amount' => $shippingAmount,
                'total_amount' => $totalAmount,
            ],
            'message' => 'Cart calculated successfully',
        ]);
    }
}
