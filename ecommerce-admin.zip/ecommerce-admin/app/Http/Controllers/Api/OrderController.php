<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;

class OrderController extends Controller
{
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'customer_name' => 'required|string|max:255',
            'customer_email' => 'nullable|email|max:255',
            'customer_phone' => 'required|string|max:20',
            'customer_address' => 'required|string|max:500',
            'customer_district' => 'required|string|max:100',
            'customer_city' => 'required|string|max:100',
            'payment_method' => 'required|string|in:cod,card',
        ]);

        DB::beginTransaction();

        try {
            // Generate unique order number (zz-1001, zz-1002, etc.)
            $lastOrder = Order::orderBy('id', 'desc')->first();
            $orderNumber = $lastOrder ? 'zz-' . (1000 + $lastOrder->id + 1) : 'zz-1001';

            // Calculate totals
            $subtotal = 0;
            $orderItems = [];

            foreach ($request->items as $item) {
                $product = Product::findOrFail($item['product_id']);
                
                if (!$product->is_active || $product->stock_status === 'out_of_stock') {
                    throw new \Exception("Product {$product->name} is not available");
                }

                if ($product->stock_quantity < $item['quantity']) {
                    throw new \Exception("Insufficient stock for {$product->name}");
                }

                $unitPrice = $product->sale_price ?? $product->price;
                $totalPrice = $unitPrice * $item['quantity'];
                $subtotal += $totalPrice;

                $orderItems[] = [
                    'product_id' => $product->id,
                    'product_name' => $product->name,
                    'product_sku' => $product->sku,
                    'quantity' => $item['quantity'],
                    'unit_price' => $unitPrice,
                    'total_price' => $totalPrice,
                    'product_attributes' => $product->attributes,
                ];
            }

            $taxAmount = $subtotal * 0.1; // 10% tax
            $shippingAmount = 10.00; // Fixed shipping
            $totalAmount = $subtotal + $taxAmount + $shippingAmount;

            // Prepare customer address data
            $customerAddress = [
                'name' => $request->customer_name,
                'email' => $request->customer_email ?: null, // Handle null email
                'phone' => $request->customer_phone,
                'address' => $request->customer_address,
                'district' => $request->customer_district,
                'city' => $request->customer_city,
            ];

            // Create order
            $order = Order::create([
                'order_number' => $orderNumber,
                'user_id' => null, // No user required for guest checkout
                'status' => 'pending',
                'payment_status' => $request->payment_method === 'cod' ? 'pending' : 'pending',
                'payment_method' => $request->payment_method,
                'subtotal' => $subtotal,
                'tax_amount' => $taxAmount,
                'shipping_amount' => $shippingAmount,
                'total_amount' => $totalAmount,
                'billing_address' => $customerAddress,
                'shipping_address' => $customerAddress, // Same as billing for simplicity
            ]);

            // Create order items
            foreach ($orderItems as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    ...$item
                ]);

                // Update product stock
                $product = Product::find($item['product_id']);
                $product->decrement('stock_quantity', $item['quantity']);
                
                // Update stock status
                if ($product->stock_quantity <= 0) {
                    $product->update(['stock_status' => 'out_of_stock']);
                } elseif ($product->stock_quantity <= 10) {
                    $product->update(['stock_status' => 'low_stock']);
                }
            }

            DB::commit();

            // Send confirmation email only if email is provided
            if ($request->customer_email) {
                try {
                    $this->sendOrderConfirmationEmail($order);
                } catch (\Exception $e) {
                    // Log email error but don't fail the order
                    \Log::error('Failed to send order confirmation email: ' . $e->getMessage());
                }
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'order' => $order->load(['items.product']),
                    'order_number' => $order->order_number,
                ],
                'message' => "Order has been placed successfully. Your order number is {$order->order_number}",
            ], 201);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function show(Order $order): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => $order->load(['items.product']),
            'message' => 'Order retrieved successfully',
        ]);
    }

    private function sendOrderConfirmationEmail(Order $order)
    {
        $customerEmail = $order->billing_address['email'];
        $customerName = $order->billing_address['name'];
        
        // Double check email exists
        if (!$customerEmail) {
            \Log::info('No email provided for order confirmation', ['order_id' => $order->id]);
            return;
        }
        
        $subject = "Order Confirmation - {$order->order_number}";
        $message = "
        Dear {$customerName},
        
        Thank you for your order! Your order has been placed successfully.
        
        Order Details:
        Order Number: {$order->order_number}
        Total Amount: ₨{$order->total_amount}
        Payment Method: " . ($order->payment_method === 'cod' ? 'Cash on Delivery' : 'Card Payment') . "
        
        Items Ordered:
        ";
        
        foreach ($order->items as $item) {
            $message .= "- {$item->product_name} (Qty: {$item->quantity}) - ₨{$item->total_price}\n";
        }
        
        $message .= "
        
        Delivery Address:
        {$order->billing_address['address']}
        {$order->billing_address['district']}, {$order->billing_address['city']}
        
        We will contact you soon for delivery arrangements.
        
        Best regards,
        Zer Zabar Team
        ";
        
        // For now, we'll just log the email. In production, you'd use Laravel's Mail facade
        \Log::info("Order confirmation email for {$order->order_number}:", [
            'to' => $customerEmail,
            'subject' => $subject,
            'message' => $message
        ]);
    }
}
