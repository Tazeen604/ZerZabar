<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Product;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class NotificationController extends Controller
{
    /**
     * Get all notifications
     */
    public function index(): JsonResponse
    {
        try {
            $notifications = Notification::orderBy('created_at', 'desc')->get();
            
            return response()->json([
                'success' => true,
                'data' => $notifications
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch notifications: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Mark notification as read
     */
    public function markAsRead($id): JsonResponse
    {
        try {
            $notification = Notification::findOrFail($id);
            $notification->markAsRead();
            
            return response()->json([
                'success' => true,
                'message' => 'Notification marked as read'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to mark notification as read: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Mark all notifications as read
     */
    public function markAllAsRead(): JsonResponse
    {
        try {
            Notification::markAllAsRead();
            
            return response()->json([
                'success' => true,
                'message' => 'All notifications marked as read'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to mark all notifications as read: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Clear all notifications
     */
    public function destroy(): JsonResponse
    {
        try {
            Notification::truncate();
            
            return response()->json([
                'success' => true,
                'message' => 'All notifications cleared'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to clear notifications: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check for low stock and create notifications
     */
    public function checkLowStock(): JsonResponse
    {
        try {
            $lowStockEnabled = Setting::get('low_stock_notification', true);
            
            if (!$lowStockEnabled) {
                return response()->json([
                    'success' => true,
                    'message' => 'Low stock notifications are disabled'
                ]);
            }

            $lowStockThreshold = Setting::get('low_stock_threshold', 10);
            $outOfStockThreshold = Setting::get('out_of_stock_threshold', 0);
            
            // Get products that are low stock or out of stock
            $lowStockProducts = Product::where('stock_quantity', '>', $outOfStockThreshold)
                ->where('stock_quantity', '<=', $lowStockThreshold)
                ->get();

            $outOfStockProducts = Product::where('stock_quantity', '<=', $outOfStockThreshold)
                ->get();

            $notificationsCreated = 0;

            // Create notifications for low stock products
            foreach ($lowStockProducts as $product) {
                // Check if notification already exists for this product
                $existingNotification = Notification::where('type', 'low_stock')
                    ->where('data->product_id', $product->id)
                    ->where('read', false)
                    ->first();

                if (!$existingNotification) {
                    Notification::createLowStockNotification($product);
                    $notificationsCreated++;
                }
            }

            // Create notifications for out of stock products
            foreach ($outOfStockProducts as $product) {
                $existingNotification = Notification::where('type', 'out_of_stock')
                    ->where('data->product_id', $product->id)
                    ->where('read', false)
                    ->first();

                if (!$existingNotification) {
                    Notification::create([
                        'type' => 'out_of_stock',
                        'title' => 'Out of Stock Alert',
                        'message' => "Product '{$product->name}' is out of stock. Current quantity: {$product->stock_quantity}",
                        'data' => [
                            'product_id' => $product->id,
                            'product_name' => $product->name,
                            'stock_quantity' => $product->stock_quantity,
                        ]
                    ]);
                    $notificationsCreated++;
                }
            }

            return response()->json([
                'success' => true,
                'message' => "Created {$notificationsCreated} new notifications",
                'notifications_created' => $notificationsCreated
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to check low stock: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get unread count
     */
    public function unreadCount(): JsonResponse
    {
        try {
            $count = Notification::getUnreadCount();
            
            return response()->json([
                'success' => true,
                'count' => $count
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get unread count: ' . $e->getMessage()
            ], 500);
        }
    }
}