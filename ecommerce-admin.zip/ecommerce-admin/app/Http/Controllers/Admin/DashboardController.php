<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Inventory;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(): JsonResponse
    {
        try {
            // Get total products
            $totalProducts = Product::count();
            
            // Get active products
            $activeProducts = Product::where('is_active', true)->count();
            
            // Get featured products
            $featuredProducts = Product::where('is_featured', true)->count();
            
            // Get low stock products (less than 10)
            $lowStockProducts = Product::where('stock_quantity', '<', 10)->count();
            
            // Get out of stock products
            $outOfStockProducts = Product::where('stock_quantity', 0)->count();
            
            // Get total revenue (sum of all product prices - this is a simplified calculation)
            $totalRevenue = Product::sum('price') ?? 0;
            
            // Get average product price
            $averagePrice = Product::avg('price') ?? 0;
            
            // Get products by category
            $productsByCategory = Category::withCount('products')->get();
            
            // Get recent products (last 5)
            $recentProducts = Product::with(['category', 'images'])
                ->orderBy('created_at', 'desc')
                ->limit(5)
                ->get();
            
            // Get recent orders (last 10)
            $recentOrders = Order::with(['user', 'items.product'])
                ->orderBy('created_at', 'desc')
                ->limit(10)
                ->get();
            
            // Get top categories by product count
            $topCategories = Category::withCount('products')
                ->orderBy('products_count', 'desc')
                ->limit(5)
                ->get();
            
            // Get inventory summary (handle empty inventory table)
            $inventorySummary = [
                'total_quantity' => Inventory::sum('quantity') ?? 0,
                'reserved_quantity' => Inventory::sum('reserved_quantity') ?? 0,
                'available_quantity' => Inventory::sum(DB::raw('quantity - reserved_quantity')) ?? 0,
            ];
            
            // Get products with sizes and colors
            $productsWithVariants = Product::whereNotNull('sizes')
                ->orWhereNotNull('colors')
                ->count();
            
            // Get size distribution (handle JSON fields safely)
            $sizeDistribution = [];
            try {
                $productsWithSizes = Product::whereNotNull('sizes')->get();
                foreach ($productsWithSizes as $product) {
                    $sizes = is_string($product->sizes) ? json_decode($product->sizes, true) : $product->sizes;
                    if (is_array($sizes)) {
                        foreach ($sizes as $size) {
                            $sizeDistribution[$size] = ($sizeDistribution[$size] ?? 0) + 1;
                        }
                    }
                }
            } catch (\Exception $e) {
                $sizeDistribution = [];
            }
            
            // Get color distribution (handle JSON fields safely)
            $colorDistribution = [];
            try {
                $productsWithColors = Product::whereNotNull('colors')->get();
                foreach ($productsWithColors as $product) {
                    $colors = is_string($product->colors) ? json_decode($product->colors, true) : $product->colors;
                    if (is_array($colors)) {
                        foreach ($colors as $color) {
                            $colorDistribution[$color] = ($colorDistribution[$color] ?? 0) + 1;
                        }
                    }
                }
            } catch (\Exception $e) {
                $colorDistribution = [];
            }
            
            $dashboardData = [
                'stats' => [
                    'total_products' => $totalProducts,
                    'active_products' => $activeProducts,
                    'featured_products' => $featuredProducts,
                    'low_stock_products' => $lowStockProducts,
                    'out_of_stock_products' => $outOfStockProducts,
                    'total_revenue' => round($totalRevenue ?? 0, 2),
                    'average_price' => round($averagePrice ?? 0, 2),
                ],
                'inventory' => $inventorySummary,
                'categories' => [
                    'total_categories' => Category::count(),
                    'products_by_category' => $productsByCategory,
                    'top_categories' => $topCategories,
                ],
                'products' => [
                    'recent_products' => $recentProducts,
                    'products_with_variants' => $productsWithVariants,
                ],
                'recent_orders' => $recentOrders,
                'variants' => [
                    'size_distribution' => $sizeDistribution,
                    'color_distribution' => $colorDistribution,
                ],
                'last_updated' => now()->toISOString(),
            ];
            
            return response()->json([
                'success' => true,
                'data' => $dashboardData
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch dashboard data',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
