<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class SettingsController extends Controller
{
    /**
     * Get all settings
     */
    public function index(): JsonResponse
    {
        try {
            $settings = Setting::getAll();
            
            return response()->json([
                'success' => true,
                'data' => $settings
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch settings: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get a specific setting
     */
    public function show($key): JsonResponse
    {
        try {
            $value = Setting::get($key);
            
            return response()->json([
                'success' => true,
                'data' => ['key' => $key, 'value' => $value]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch setting: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update settings
     */
    public function update(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'low_stock_threshold' => 'nullable|integer|min:0',
                'new_arrivals_days' => 'nullable|integer|min:1|max:365',
                'out_of_stock_threshold' => 'nullable|integer|min:0',
                'max_product_images' => 'nullable|integer|min:1|max:20',
                'auto_approve_products' => 'nullable|boolean',
                'require_product_approval' => 'nullable|boolean',
                'order_auto_confirm' => 'nullable|boolean',
                'order_confirmation_email' => 'nullable|boolean',
                'low_stock_notification' => 'nullable|boolean',
                'maintenance_mode' => 'nullable|boolean',
                'debug_mode' => 'nullable|boolean',
                'backup_frequency' => 'nullable|in:daily,weekly,monthly',
                'email_notifications' => 'nullable|boolean',
                'sms_notifications' => 'nullable|boolean',
                'push_notifications' => 'nullable|boolean',
                'default_theme' => 'nullable|in:light,dark,auto',
                'accent_color' => 'nullable|string',
                'primary_color' => 'nullable|string',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $settings = $request->all();
            
            foreach ($settings as $key => $value) {
                if ($value !== null) {
                    $type = $this->getSettingType($key);
                    $category = $this->getSettingCategory($key);
                    $description = $this->getSettingDescription($key);
                    $isPublic = $this->isPublicSetting($key);
                    
                    Setting::set($key, $value, $type, $description, $category, $isPublic);
                }
            }

            // Clear all caches
            Setting::clearCache();

            return response()->json([
                'success' => true,
                'message' => 'Settings updated successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update settings: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get public settings (for frontend)
     */
    public function public(): JsonResponse
    {
        try {
            $settings = Setting::getPublic();
            
            return response()->json([
                'success' => true,
                'data' => $settings
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch public settings: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Reset settings to defaults
     */
    public function reset(): JsonResponse
    {
        try {
            $defaultSettings = $this->getDefaultSettings();
            
            foreach ($defaultSettings as $key => $config) {
                Setting::set(
                    $key,
                    $config['value'],
                    $config['type'],
                    $config['description'],
                    $config['category'],
                    $config['is_public']
                );
            }

            Setting::clearCache();

            return response()->json([
                'success' => true,
                'message' => 'Settings reset to defaults'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to reset settings: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get setting type based on key
     */
    private function getSettingType($key): string
    {
        $booleanSettings = [
            'auto_approve_products',
            'require_product_approval',
            'order_auto_confirm',
            'order_confirmation_email',
            'low_stock_notification',
            'maintenance_mode',
            'debug_mode',
            'email_notifications',
            'sms_notifications',
            'push_notifications'
        ];

        $numberSettings = [
            'low_stock_threshold',
            'new_arrivals_days',
            'out_of_stock_threshold',
            'max_product_images'
        ];

        if (in_array($key, $booleanSettings)) {
            return 'boolean';
        } elseif (in_array($key, $numberSettings)) {
            return 'integer';
        } else {
            return 'string';
        }
    }

    /**
     * Get setting category based on key
     */
    private function getSettingCategory($key): string
    {
        $inventorySettings = ['low_stock_threshold', 'new_arrivals_days', 'out_of_stock_threshold'];
        $productSettings = ['max_product_images', 'auto_approve_products', 'require_product_approval'];
        $orderSettings = ['order_auto_confirm', 'order_confirmation_email', 'low_stock_notification'];
        $systemSettings = ['maintenance_mode', 'debug_mode', 'backup_frequency'];
        $notificationSettings = ['email_notifications', 'sms_notifications', 'push_notifications'];
        $themeSettings = ['default_theme', 'accent_color', 'primary_color'];

        if (in_array($key, $inventorySettings)) {
            return 'inventory';
        } elseif (in_array($key, $productSettings)) {
            return 'product';
        } elseif (in_array($key, $orderSettings)) {
            return 'order';
        } elseif (in_array($key, $systemSettings)) {
            return 'system';
        } elseif (in_array($key, $notificationSettings)) {
            return 'notification';
        } elseif (in_array($key, $themeSettings)) {
            return 'theme';
        } else {
            return 'general';
        }
    }

    /**
     * Get setting description based on key
     */
    private function getSettingDescription($key): string
    {
        $descriptions = [
            'low_stock_threshold' => 'Minimum quantity before marking as low stock',
            'new_arrivals_days' => 'Number of days to consider products as new arrivals',
            'out_of_stock_threshold' => 'Quantity below which product is considered out of stock',
            'max_product_images' => 'Maximum number of images allowed per product',
            'auto_approve_products' => 'Automatically approve new products',
            'require_product_approval' => 'Require manual approval for new products',
            'order_auto_confirm' => 'Automatically confirm orders upon payment',
            'order_confirmation_email' => 'Send email confirmations for orders',
            'low_stock_notification' => 'Send notifications when stock is low',
            'maintenance_mode' => 'Enable maintenance mode for system updates',
            'debug_mode' => 'Enable debug logging and detailed error messages',
            'backup_frequency' => 'How often to create system backups',
            'email_notifications' => 'Enable email notifications',
            'sms_notifications' => 'Enable SMS notifications',
            'push_notifications' => 'Enable push notifications',
            'default_theme' => 'Default theme for new users',
            'accent_color' => 'Primary accent color for the system',
            'primary_color' => 'Primary color for the system',
        ];

        return $descriptions[$key] ?? 'System setting';
    }

    /**
     * Check if setting is public
     */
    private function isPublicSetting($key): bool
    {
        $publicSettings = [
            'low_stock_threshold',
            'new_arrivals_days',
            'default_theme',
            'accent_color',
            'primary_color'
        ];

        return in_array($key, $publicSettings);
    }

    /**
     * Get default settings
     */
    private function getDefaultSettings(): array
    {
        return [
            'low_stock_threshold' => [
                'value' => 10,
                'type' => 'integer',
                'description' => 'Minimum quantity before marking as low stock',
                'category' => 'inventory',
                'is_public' => true
            ],
            'new_arrivals_days' => [
                'value' => 7,
                'type' => 'integer',
                'description' => 'Number of days to consider products as new arrivals',
                'category' => 'inventory',
                'is_public' => true
            ],
            'out_of_stock_threshold' => [
                'value' => 0,
                'type' => 'integer',
                'description' => 'Quantity below which product is considered out of stock',
                'category' => 'inventory',
                'is_public' => false
            ],
            'max_product_images' => [
                'value' => 5,
                'type' => 'integer',
                'description' => 'Maximum number of images allowed per product',
                'category' => 'product',
                'is_public' => false
            ],
            'auto_approve_products' => [
                'value' => false,
                'type' => 'boolean',
                'description' => 'Automatically approve new products',
                'category' => 'product',
                'is_public' => false
            ],
            'require_product_approval' => [
                'value' => true,
                'type' => 'boolean',
                'description' => 'Require manual approval for new products',
                'category' => 'product',
                'is_public' => false
            ],
            'order_auto_confirm' => [
                'value' => false,
                'type' => 'boolean',
                'description' => 'Automatically confirm orders upon payment',
                'category' => 'order',
                'is_public' => false
            ],
            'order_confirmation_email' => [
                'value' => true,
                'type' => 'boolean',
                'description' => 'Send email confirmations for orders',
                'category' => 'order',
                'is_public' => false
            ],
            'low_stock_notification' => [
                'value' => true,
                'type' => 'boolean',
                'description' => 'Send notifications when stock is low',
                'category' => 'order',
                'is_public' => false
            ],
            'maintenance_mode' => [
                'value' => false,
                'type' => 'boolean',
                'description' => 'Enable maintenance mode for system updates',
                'category' => 'system',
                'is_public' => false
            ],
            'debug_mode' => [
                'value' => false,
                'type' => 'boolean',
                'description' => 'Enable debug logging and detailed error messages',
                'category' => 'system',
                'is_public' => false
            ],
            'backup_frequency' => [
                'value' => 'daily',
                'type' => 'string',
                'description' => 'How often to create system backups',
                'category' => 'system',
                'is_public' => false
            ],
            'email_notifications' => [
                'value' => true,
                'type' => 'boolean',
                'description' => 'Enable email notifications',
                'category' => 'notification',
                'is_public' => false
            ],
            'sms_notifications' => [
                'value' => false,
                'type' => 'boolean',
                'description' => 'Enable SMS notifications',
                'category' => 'notification',
                'is_public' => false
            ],
            'push_notifications' => [
                'value' => true,
                'type' => 'boolean',
                'description' => 'Enable push notifications',
                'category' => 'notification',
                'is_public' => false
            ],
            'default_theme' => [
                'value' => 'light',
                'type' => 'string',
                'description' => 'Default theme for new users',
                'category' => 'theme',
                'is_public' => true
            ],
            'accent_color' => [
                'value' => '#FFD700',
                'type' => 'string',
                'description' => 'Primary accent color for the system',
                'category' => 'theme',
                'is_public' => true
            ],
            'primary_color' => [
                'value' => '#2C2C2C',
                'type' => 'string',
                'description' => 'Primary color for the system',
                'category' => 'theme',
                'is_public' => true
            ],
        ];
    }
}