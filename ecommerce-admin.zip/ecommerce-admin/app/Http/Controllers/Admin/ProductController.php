<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Category;
use App\Models\ProductImage;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    public function nextId(): JsonResponse
    {
        try {
            // Get all products and find the highest product_id number
            $products = Product::select('product_id')->get();
            $maxNumber = 0;
            
            \Log::info('NextId API called - Total products: ' . $products->count());
            
            foreach ($products as $product) {
                \Log::info('Checking product ID: ' . $product->product_id);
                if (preg_match('/zz-prd-(\d+)/', $product->product_id, $matches)) {
                    $number = (int) $matches[1];
                    \Log::info('Extracted number: ' . $number);
                    if ($number > $maxNumber) {
                        $maxNumber = $number;
                    }
                }
            }
            
            // Generate next ID
            $nextNumber = $maxNumber + 1;
            $nextId = 'zz-prd-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
            
            \Log::info('Max number found: ' . $maxNumber);
            \Log::info('Generated next ID: ' . $nextId);
            
            return response()->json([
                'success' => true,
                'next_id' => $nextId
            ]);
        } catch (\Exception $e) {
            \Log::error('NextId API error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate next product ID: ' . $e->getMessage()
            ], 500);
        }
    }

    public function index(Request $request): JsonResponse
    {
        try {
            $query = Product::with(['category', 'images', 'inventory']);

          // Filter by category
    if ($request->has('category_id') && !empty($request->get('category_id'))) {
        $query->where('category_id', $request->get('category_id'));
    }

    // Filter by search
    if ($request->has('search') && !empty(trim($request->get('search')))) {
        $search = $request->get('search');
        $query->where(function ($q) use ($search) {
            $q->where('name', 'like', "%{$search}%")
              ->orWhere('sku', 'like', "%{$search}%")
              ->orWhere('description', 'like', "%{$search}%");
        });
    }

            // Filter by status
            if ($request->filled('status')) {
                $query->where('stock_status', $request->get('status'));
            }

            // Filter by active status
            if ($request->filled('is_active')) {
                $query->where('is_active', $request->boolean('is_active'));
            }

           // $products = $query->paginate($request->get('per_page', 15));
    $products = $query->get();
            return response()->json([
                'success' => true,
                'data' => $products,
                'message' => 'Products retrieved successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error retrieving products: ' . $e->getMessage(),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function store(Request $request): JsonResponse
    {
        try {
            $request->validate([
                'product_id' => 'required|string|unique:products,product_id',
                'name' => 'required|string|min:3|max:255',
                'description' => 'required|string|min:10',
                'sku' => 'required|string|unique:products,sku',
                'price' => 'required|numeric|min:0.01',
                'sale_price' => 'nullable|numeric|min:0|lt:price',
                'category_id' => 'required|exists:categories,id',
                'subcategory_id' => 'nullable|exists:subcategories,id',
                'stock_quantity' => 'required|integer|min:0',
                'weight' => 'nullable|numeric|min:0',
                'dimensions' => 'nullable|string',
                'attributes' => 'nullable|string', // JSON string
                'sizes' => 'nullable|string', // JSON string
                'colors' => 'nullable|string', // JSON string
                'images' => 'required|array|min:1',
                'images.*' => 'required|image|mimes:jpeg,png,jpg,gif|max:512', // 512KB = 500KB approx
                'is_active' => 'nullable|in:0,1,true,false',
                'is_featured' => 'nullable|in:0,1,true,false',
            ], [
                'product_id.required' => 'Product ID is required',
                'product_id.unique' => 'This Product ID already exists',
                'name.required' => 'Product name is required',
                'name.min' => 'Product name must be at least 3 characters',
                'description.required' => 'Product description is required',
                'description.min' => 'Description must be at least 10 characters',
                'sku.required' => 'SKU is required',
                'sku.unique' => 'This SKU already exists',
                'price.required' => 'Price is required',
                'price.min' => 'Price must be greater than 0',
                'sale_price.lt' => 'Sale price must be less than regular price',
                'category_id.required' => 'Category is required',
                'category_id.exists' => 'Selected category does not exist',
                'stock_quantity.required' => 'Stock quantity is required',
                'stock_quantity.min' => 'Stock quantity cannot be negative',
                'images.required' => 'At least one product image is required',
                'images.min' => 'At least one product image is required',
                'images.*.max' => 'Each image must be less than 500KB',
                'images.*.image' => 'File must be an image',
                'images.*.mimes' => 'Image must be jpeg, png, jpg, or gif format',
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors()
            ], 422);
        }

        try {
            $product = Product::create([
                'product_id' => $request->product_id,
                'name' => $request->name,
                'slug' => Str::slug($request->name),
                'description' => $request->description,
                'sku' => $request->sku,
                'price' => $request->price,
                'sale_price' => $request->sale_price,
                'category_id' => $request->category_id,
                'subcategory_id' => $request->subcategory_id,
                'stock_quantity' => $request->stock_quantity,
                'stock_status' => $request->stock_quantity > 0 ? 'in_stock' : 'out_of_stock',
                'weight' => $request->weight,
                'dimensions' => $request->dimensions,
                'attributes' => $this->decodeJsonField($request->attributes),
                'sizes' => $this->decodeJsonField($request->sizes),
                'colors' => $this->decodeJsonField($request->colors),
                'is_active' => $request->boolean('is_active', true),
                'is_featured' => $request->boolean('is_featured', false),
            ]);

            // Handle image uploads
            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $index => $image) {
                    $path = $image->store('products', 'public');
                    ProductImage::create([
                        'product_id' => $product->id,
                        'image_path' => $path,
                        'is_primary' => $index === 0,
                        'sort_order' => $index,
                    ]);
                }
            }

            // Create inventory record
            $product->inventory()->create([
                'quantity' => $request->stock_quantity,
                'cost_price' => $request->cost_price ?? null,
            ]);

            return response()->json([
                'success' => true,
                'data' => $product->load(['category', 'images', 'inventory']),
                'message' => 'Product created successfully',
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error creating product: ' . $e->getMessage(),
                'error' => $e->getMessage()
            ], 500);
        }

     
    }

    public function show(Product $product): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => $product->load(['category', 'images', 'inventory', 'inventoryHistory']),
            'message' => 'Product retrieved successfully',
        ]);
    }

    public function update(Request $request, Product $product): JsonResponse
    {
        // Debug: Log the incoming request data
        \Log::info('Product update request:', [
            'product_id' => $product->id,
            'request_data' => $request->all(),
            'files' => $request->files->all()
        ]);
        
        $request->validate([
            '_method' => 'sometimes|string|in:PUT',
            'name' => 'sometimes|string|max:255',
            'description' => 'sometimes|string',
            'sku' => 'sometimes|string|unique:products,sku,' . $product->id,
            'price' => 'sometimes|numeric|min:0',
            'sale_price' => 'nullable|numeric|min:0',
            'category_id' => 'sometimes|exists:categories,id',
            'stock_quantity' => 'sometimes|integer|min:0',
            'is_active' => 'sometimes|in:0,1,true,false',
            'is_featured' => 'sometimes|in:0,1,true,false',
            'weight' => 'nullable|numeric|min:0',
            'dimensions' => 'nullable|string',
            'attributes' => 'nullable|string', // Changed to string since we send JSON
            'sizes' => 'nullable|string', // JSON string
            'colors' => 'nullable|string', // JSON string
            'images' => 'sometimes|array|max:5',
            'images.*' => 'sometimes|image|mimes:jpeg,png,jpg,gif|max:2048',
            'images_to_delete' => 'sometimes|string',
        ]);

        // Use database transaction to ensure data consistency
        try {
            \DB::beginTransaction();

            // Prepare update data with proper field normalization
            $updateData = [];

            // Handle basic fields
            if ($request->filled('name')) {
                $updateData['name'] = $request->name;
            }
            if ($request->filled('description')) {
                $updateData['description'] = $request->description;
            }
            if ($request->filled('sku')) {
                $updateData['sku'] = $request->sku;
            }
            if ($request->filled('price')) {
                $updateData['price'] = $request->price;
            }
            if ($request->filled('sale_price')) {
                $updateData['sale_price'] = $request->sale_price;
            } else {
                $updateData['sale_price'] = null; // Set to null if empty
            }
            if ($request->filled('category_id')) {
                $updateData['category_id'] = $request->category_id;
            }
            if ($request->filled('stock_quantity')) {
                $updateData['stock_quantity'] = $request->stock_quantity;
            }
            if ($request->filled('weight')) {
                $updateData['weight'] = $request->weight;
            } else {
                $updateData['weight'] = null;
            }
            if ($request->filled('dimensions')) {
                $updateData['dimensions'] = $request->dimensions;
            } else {
                $updateData['dimensions'] = null;
            }

            // Handle attributes JSON parsing
            if ($request->has('attributes')) {
                $updateData['attributes'] = $this->decodeJsonField($request->attributes);
            } else {
                $updateData['attributes'] = [];
            }

            // Handle sizes JSON parsing
            if ($request->has('sizes')) {
                $updateData['sizes'] = $this->decodeJsonField($request->sizes);
            } else {
                $updateData['sizes'] = [];
            }

            // Handle colors JSON parsing
            if ($request->has('colors')) {
                $updateData['colors'] = $this->decodeJsonField($request->colors);
            } else {
                $updateData['colors'] = [];
            }

            // Handle boolean fields properly
            if ($request->has('is_active')) {
                $updateData['is_active'] = in_array($request->input('is_active'), ['1', 'true', 1, true]);
            }
            if ($request->has('is_featured')) {
                $updateData['is_featured'] = in_array($request->input('is_featured'), ['1', 'true', 1, true]);
            }

            // Handle slug update if name changed
            if ($request->filled('name')) {
                $updateData['slug'] = Str::slug($request->name);
            }

            // Handle stock status if stock_quantity changed
            if ($request->filled('stock_quantity')) {
                $status = $request->stock_quantity > 10 ? 'in_stock' : 
                         ($request->stock_quantity > 0 ? 'low_stock' : 'out_of_stock');
                $updateData['stock_status'] = $status;
            }

            \Log::info('Product update data:', [
                'product_id' => $product->id,
                'update_data' => $updateData
            ]);
            
            // Update the product
            $product->update($updateData);
            
            \Log::info('Product updated successfully:', [
                'product_id' => $product->id,
                'updated_product' => $product->fresh()->toArray()
            ]);

            // All updates are now handled in the single update() call above

            // Handle image deletion if any images are marked for deletion
            $imagesToDelete = [];
            if ($request->has('images_to_delete')) {
                // Try to get as array first (if sent as images_to_delete[0], images_to_delete[1], etc.)
                $imagesToDelete = $request->input('images_to_delete');
                
                // If it's a JSON string, decode it
                if (is_string($imagesToDelete)) {
                    $imagesToDelete = json_decode($imagesToDelete, true) ?? [];
                }
                
                // Ensure it's an array
                if (!is_array($imagesToDelete)) {
                    $imagesToDelete = [];
                }
            }
            
            \Log::info('Images to delete:', ['images_to_delete' => $imagesToDelete]);
            
            if (count($imagesToDelete) > 0) {
                // Validate that all image IDs exist and belong to this product
                $validImageIds = $product->images()->whereIn('id', $imagesToDelete)->pluck('id')->toArray();
                $invalidIds = array_diff($imagesToDelete, $validImageIds);
                
                if (!empty($invalidIds)) {
                    \Log::warning('Invalid image IDs provided for deletion:', ['invalid_ids' => $invalidIds]);
                }
                
                foreach ($validImageIds as $imageId) {
                    $image = $product->images()->find($imageId);
                    if ($image) {
                        \Log::info('Deleting image:', [
                            'image_id' => $imageId,
                            'image_path' => $image->image_path
                        ]);
                        
                        // Delete the file from storage
                        if (Storage::disk('public')->exists($image->image_path)) {
                            Storage::disk('public')->delete($image->image_path);
                            \Log::info('Image file deleted from storage');
                        }
                        
                        // Delete the database record
                        $image->delete();
                        \Log::info('Image record deleted from database');
                    } else {
                        \Log::warning('Image not found for deletion:', ['image_id' => $imageId]);
                    }
                }
            }

            // Handle new images if any are uploaded
            if ($request->hasFile('images')) {
                $images = $request->file('images');
                \Log::info('Adding new images:', ['count' => count($images)]);
                
                foreach ($images as $image) {
                    $filename = time() . '_' . $image->getClientOriginalName();
                    $path = $image->storeAs('products', $filename, 'public');
                    
                    $newImage = $product->images()->create([
                        'image_path' => $path,
                        'alt_text' => $product->name,
                        'is_primary' => false,
                    ]);
                    
                    \Log::info('New image created:', [
                        'image_id' => $newImage->id,
                        'path' => $path
                    ]);
                }
            }

            // Commit the transaction
            \DB::commit();
            
            \Log::info('Product update transaction committed successfully');

            return response()->json([
                'success' => true,
                'data' => $product->load(['category', 'images', 'inventory']),
                'message' => 'Product updated successfully',
            ]);

        } catch (\Exception $e) {
            // Rollback the transaction on error
            \DB::rollback();
            
            \Log::error('Product update failed:', [
                'product_id' => $product->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Error updating product: ' . $e->getMessage(),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function destroy(Product $product): JsonResponse
    {
        // Delete associated images
        foreach ($product->images as $image) {
            Storage::disk('public')->delete($image->image_path);
        }

        $product->delete();

        return response()->json([
            'success' => true,
            'message' => 'Product deleted successfully',
        ]);
    }

    /**
     * Safely decode JSON field from request
     */
    private function decodeJsonField($field)
    {
        \Log::info('decodeJsonField called with:', [
            'field' => $field,
            'type' => gettype($field),
            'is_empty' => empty($field)
        ]);

        if (empty($field)) {
            return [];
        }

        // If it's already an array, return it
        if (is_array($field)) {
            \Log::info('Field is already array, returning as-is');
            return $field;
        }

        // If it's a string, try to decode it
        if (is_string($field)) {
            \Log::info('Field is string, attempting to decode JSON');
            $decoded = json_decode($field, true);
            \Log::info('JSON decode result:', [
                'decoded' => $decoded,
                'json_last_error' => json_last_error(),
                'json_last_error_msg' => json_last_error_msg()
            ]);
            return is_array($decoded) ? $decoded : [];
        }

        // If it's any other type, return empty array
        \Log::info('Field is neither array nor string, returning empty array');
        return [];
    }
}
