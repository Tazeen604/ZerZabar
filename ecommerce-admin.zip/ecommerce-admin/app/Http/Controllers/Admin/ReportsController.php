<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\Category;
use App\Models\User;
use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReportsController extends Controller
{
    /**
     * Get dashboard statistics
     */
    public function getDashboardStats()
    {
        try {
            $currentMonth = Carbon::now()->startOfMonth();
            $lastMonth = Carbon::now()->subMonth()->startOfMonth();
            
            // Current month stats
            $thisMonth = [
                'revenue' => Order::where('created_at', '>=', $currentMonth)
                    ->where('status', '!=', 'cancelled')
                    ->sum('total_amount'),
                'orders' => Order::where('created_at', '>=', $currentMonth)->count(),
                'customers' => User::where('created_at', '>=', $currentMonth)->count(),
            ];
            
            // Last month stats for comparison
            $lastMonthStats = [
                'revenue' => Order::whereBetween('created_at', [$lastMonth, $currentMonth])
                    ->where('status', '!=', 'cancelled')
                    ->sum('total_amount'),
                'orders' => Order::whereBetween('created_at', [$lastMonth, $currentMonth])->count(),
            ];
            
            // Calculate growth percentages
            $growth = [
                'revenue_growth' => $lastMonthStats['revenue'] > 0 
                    ? round((($thisMonth['revenue'] - $lastMonthStats['revenue']) / $lastMonthStats['revenue']) * 100, 2)
                    : 0,
                'orders_growth' => $lastMonthStats['orders'] > 0 
                    ? round((($thisMonth['orders'] - $lastMonthStats['orders']) / $lastMonthStats['orders']) * 100, 2)
                    : 0,
            ];
            
            // Inventory stats
            $inventory = [
                'total_quantity' => Inventory::sum('quantity') ?? 0,
                'available_quantity' => Inventory::where('quantity', '>', 0)->sum('quantity') ?? 0,
                'reserved_quantity' => Inventory::where('quantity', '<=', 0)->sum('quantity') ?? 0,
                'low_stock' => Inventory::where('quantity', '<=', 10)->count(),
                'out_of_stock' => Inventory::where('quantity', '<=', 0)->count(),
                'total_items' => Inventory::count(),
            ];
            
            // Products stats
            $products = [
                'total_products' => Product::count(),
                'products_with_variants' => Product::whereHas('inventory')->count(),
                'recent_products' => Product::with('category')->latest()->limit(5)->get(),
            ];
            
            // Recent orders
            $recentOrders = Order::with(['user', 'orderItems.product'])
                ->latest()
                ->limit(10)
                ->get();
            
            return response()->json([
                'success' => true,
                'data' => [
                    'this_month' => $thisMonth,
                    'last_month' => $lastMonthStats,
                    'growth' => $growth,
                    'inventory' => $inventory,
                    'products' => $products,
                    'recent_orders' => $recentOrders,
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch dashboard stats: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get sales report
     */
    public function getSalesReport(Request $request)
    {
        try {
            $dateFrom = $request->get('date_from', Carbon::now()->subDays(30)->format('Y-m-d'));
            $dateTo = $request->get('date_to', Carbon::now()->format('Y-m-d'));
            $period = $request->get('period', 'daily');
            
            $query = Order::whereBetween('created_at', [$dateFrom, $dateTo])
                ->where('status', '!=', 'cancelled');
            
            // Group by period
            if ($period === 'daily') {
                $salesData = $query->selectRaw('DATE(created_at) as period, COUNT(*) as orders_count, SUM(total_amount) as total_revenue')
                    ->groupBy(DB::raw('DATE(created_at)'))
                    ->orderBy(DB::raw('DATE(created_at)'))
                    ->get();
            } elseif ($period === 'weekly') {
                $salesData = $query->selectRaw('YEARWEEK(created_at) as period, COUNT(*) as orders_count, SUM(total_amount) as total_revenue')
                    ->groupBy(DB::raw('YEARWEEK(created_at)'))
                    ->orderBy(DB::raw('YEARWEEK(created_at)'))
                    ->get();
            } else { // monthly
                $salesData = $query->selectRaw('DATE_FORMAT(created_at, "%Y-%m") as period, COUNT(*) as orders_count, SUM(total_amount) as total_revenue')
                    ->groupBy(DB::raw('DATE_FORMAT(created_at, "%Y-%m")'))
                    ->orderBy(DB::raw('DATE_FORMAT(created_at, "%Y-%m")'))
                    ->get();
            }
            
            // Calculate totals
            $totals = [
                'total_revenue' => $query->sum('total_amount') ?? 0,
                'total_orders' => $query->count(),
                'average_order_value' => $query->count() > 0 ? $query->sum('total_amount') / $query->count() : 0,
                'total_tax' => $query->sum('tax_amount') ?? 0,
            ];
            
            // Ensure we always return arrays, even if empty
            $salesData = $salesData ?: [];
            
            return response()->json([
                'success' => true,
                'data' => [
                    'report_data' => $salesData,
                    'totals' => $totals,
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch sales report: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get product sales report
     */
    public function getProductSales(Request $request)
    {
        try {
            $dateFrom = $request->get('date_from', Carbon::now()->subDays(30)->format('Y-m-d'));
            $dateTo = $request->get('date_to', Carbon::now()->format('Y-m-d'));
            
            $productSales = DB::table('order_items')
                ->join('orders', 'order_items.order_id', '=', 'orders.id')
                ->join('products', 'order_items.product_id', '=', 'products.id')
                ->whereBetween('orders.created_at', [$dateFrom, $dateTo])
                ->where('orders.status', '!=', 'cancelled')
                ->selectRaw('
                    products.id as product_id,
                    products.name as product_name,
                    products.sku as product_sku,
                    SUM(order_items.quantity) as total_quantity_sold,
                    SUM(order_items.subtotal) as total_revenue,
                    AVG(order_items.unit_price) as average_price,
                    COUNT(DISTINCT orders.id) as orders_count
                ')
                ->groupBy('products.id', 'products.name', 'products.sku')
                ->orderBy('total_revenue', 'desc')
                ->get();
            
            // Ensure we always return an array, even if empty
            $productSales = $productSales ?: [];
            
            return response()->json([
                'success' => true,
                'data' => $productSales
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch product sales: ' . $e->getMessage()
            ], 500);
        }
    }


    /**
     * Get customer statistics
     */
    public function getCustomerStats(Request $request)
    {
        try {
            $dateFrom = $request->get('date_from', Carbon::now()->subDays(30)->format('Y-m-d'));
            $dateTo = $request->get('date_to', Carbon::now()->format('Y-m-d'));
            
            $totalCustomers = User::count();
            $newCustomers = User::whereBetween('created_at', [$dateFrom, $dateTo])->count();
            
            // Calculate average order value
            $avgOrderValue = Order::whereBetween('created_at', [$dateFrom, $dateTo])
                ->where('status', '!=', 'cancelled')
                ->avg('total_amount');
            
            // Calculate repeat customers
            $repeatCustomers = User::whereHas('orders', function ($query) use ($dateFrom, $dateTo) {
                $query->whereBetween('created_at', [$dateFrom, $dateTo])
                    ->where('status', '!=', 'cancelled');
            })->whereHas('orders', function ($query) {
                $query->where('created_at', '<', Carbon::now()->subDays(30));
            })->count();
            
            return response()->json([
                'success' => true,
                'data' => [
                    'total_customers' => $totalCustomers,
                    'new_customers' => $newCustomers,
                    'average_order_value' => round($avgOrderValue, 2),
                    'repeat_customers' => $repeatCustomers,
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch customer stats: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get top customers
     */
    public function getTopCustomers(Request $request)
    {
        try {
            $dateFrom = $request->get('date_from', Carbon::now()->subDays(30)->format('Y-m-d'));
            $dateTo = $request->get('date_to', Carbon::now()->format('Y-m-d'));
            
            $topCustomers = User::withCount(['orders' => function ($query) use ($dateFrom, $dateTo) {
                $query->whereBetween('created_at', [$dateFrom, $dateTo])
                    ->where('status', '!=', 'cancelled');
            }])
            ->withSum(['orders' => function ($query) use ($dateFrom, $dateTo) {
                $query->whereBetween('created_at', [$dateFrom, $dateTo])
                    ->where('status', '!=', 'cancelled');
            }], 'total_amount')
            ->withMax(['orders' => function ($query) use ($dateFrom, $dateTo) {
                $query->whereBetween('created_at', [$dateFrom, $dateTo])
                    ->where('status', '!=', 'cancelled');
            }], 'created_at')
            ->having('orders_count', '>', 0)
            ->orderBy('orders_sum_total_amount', 'desc')
            ->limit(20)
            ->get()
            ->map(function ($customer) {
                return [
                    'id' => $customer->id,
                    'name' => $customer->name,
                    'email' => $customer->email,
                    'total_orders' => $customer->orders_count,
                    'total_spent' => $customer->orders_sum_total_amount ?? 0,
                    'average_order_value' => $customer->orders_count > 0 
                        ? round(($customer->orders_sum_total_amount ?? 0) / $customer->orders_count, 2) 
                        : 0,
                    'last_order_date' => $customer->orders_max_created_at,
                    'status' => $customer->orders_sum_total_amount > 10000 ? 'VIP' : 'Regular',
                ];
            });
            
            // Ensure we always return an array, even if empty
            $topCustomers = $topCustomers ?: [];
            
            return response()->json([
                'success' => true,
                'data' => $topCustomers
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch top customers: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get revenue report
     */
    public function getRevenueReport(Request $request)
    {
        try {
            $dateFrom = $request->get('date_from', Carbon::now()->subDays(30)->format('Y-m-d'));
            $dateTo = $request->get('date_to', Carbon::now()->format('Y-m-d'));
            
            $revenue = Order::whereBetween('created_at', [$dateFrom, $dateTo])
                ->where('status', '!=', 'cancelled');
            
            $totalRevenue = $revenue->sum('total_amount');
            $grossRevenue = $revenue->sum('subtotal');
            $netRevenue = $totalRevenue - $revenue->sum('tax_amount');
            $avgOrderValue = $revenue->count() > 0 ? $totalRevenue / $revenue->count() : 0;
            
            return response()->json([
                'success' => true,
                'data' => [
                    'total_revenue' => $totalRevenue,
                    'gross_revenue' => $grossRevenue,
                    'net_revenue' => $netRevenue,
                    'average_order_value' => round($avgOrderValue, 2),
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch revenue report: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get expense report
     */
    public function getExpenseReport(Request $request)
    {
        try {
            $dateFrom = $request->get('date_from', Carbon::now()->subDays(30)->format('Y-m-d'));
            $dateTo = $request->get('date_to', Carbon::now()->format('Y-m-d'));
            
            // This would typically come from an expenses table
            // For now, we'll return mock data
            $expenses = [
                'total_expenses' => 50000,
                'operating_expenses' => 30000,
                'marketing' => 10000,
                'administrative' => 10000,
            ];
            
            return response()->json([
                'success' => true,
                'data' => $expenses
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch expense report: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get profit and loss report
     */
    public function getProfitLossReport(Request $request)
    {
        try {
            $dateFrom = $request->get('date_from', Carbon::now()->subDays(30)->format('Y-m-d'));
            $dateTo = $request->get('date_to', Carbon::now()->format('Y-m-d'));
            
            $revenue = Order::whereBetween('created_at', [$dateFrom, $dateTo])
                ->where('status', '!=', 'cancelled')
                ->sum('total_amount');
            
            $expenses = 50000; // Mock expense data
            $netProfit = $revenue - $expenses;
            
            return response()->json([
                'success' => true,
                'data' => [
                    'total_revenue' => $revenue,
                    'total_expenses' => $expenses,
                    'net_profit' => $netProfit,
                    'product_sales' => $revenue * 0.8,
                    'shipping_revenue' => $revenue * 0.1,
                    'cogs' => $revenue * 0.4,
                    'operating_expenses' => $expenses * 0.6,
                    'marketing' => $expenses * 0.2,
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch profit loss report: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get tax report
     */
    public function getTaxReport(Request $request)
    {
        try {
            $dateFrom = $request->get('date_from', Carbon::now()->subDays(30)->format('Y-m-d'));
            $dateTo = $request->get('date_to', Carbon::now()->format('Y-m-d'));
            
            $taxData = Order::whereBetween('created_at', [$dateFrom, $dateTo])
                ->where('status', '!=', 'cancelled');
            
            $gstCollected = $taxData->sum('tax_amount');
            $gstPaid = 5000; // Mock data
            $netGst = $gstCollected - $gstPaid;
            
            return response()->json([
                'success' => true,
                'data' => [
                    'gst_collected' => $gstCollected,
                    'gst_paid' => $gstPaid,
                    'net_gst' => $netGst,
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch tax report: ' . $e->getMessage()
            ], 500);
        }
    }
}
