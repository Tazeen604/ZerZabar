<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Storage;

class InvoiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Invoice::with(['order.user']);

        // Search
        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where(function ($q) use ($search) {
                $q->where('invoice_number', 'like', "%{$search}%")
                  ->orWhereHas('order.user', function ($userQuery) use ($search) {
                      $userQuery->where('name', 'like', "%{$search}%")
                               ->orWhere('email', 'like', "%{$search}%");
                  });
            });
        }

        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->get('status'));
        }

        $invoices = $query->orderBy('created_at', 'desc')
                          ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $invoices,
            'message' => 'Invoices retrieved successfully',
        ]);
    }

    public function generate(Order $order): JsonResponse
    {
        // Check if invoice already exists
        if ($order->invoice) {
            return response()->json([
                'success' => false,
                'message' => 'Invoice already exists for this order',
            ], 422);
        }

        $invoiceNumber = 'INV-' . str_pad($order->id, 6, '0', STR_PAD_LEFT);
        
        $invoice = Invoice::create([
            'invoice_number' => $invoiceNumber,
            'order_id' => $order->id,
            'status' => 'draft',
            'issue_date' => now()->toDateString(),
            'due_date' => now()->addDays(30)->toDateString(),
            'subtotal' => $order->subtotal,
            'tax_amount' => $order->tax_amount,
            'total_amount' => $order->total_amount,
            'currency' => $order->currency,
        ]);

        return response()->json([
            'success' => true,
            'data' => $invoice->load(['order.user', 'order.items.product']),
            'message' => 'Invoice generated successfully',
        ], 201);
    }

    public function generatePDF(Invoice $invoice): JsonResponse
    {
        $invoice->load(['order.user', 'order.items.product']);
        
        $pdf = Pdf::loadView('invoice', compact('invoice'));
        $pdf->setPaper('A4', 'portrait');
        
        $filename = 'invoice-' . $invoice->invoice_number . '.pdf';
        $path = 'invoices/' . $filename;
        
        // Store PDF
        Storage::disk('public')->put($path, $pdf->output());
        
        $invoice->update([
            'pdf_path' => $path,
            'status' => 'sent',
            'sent_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'invoice' => $invoice->fresh(),
                'pdf_url' => Storage::url($path),
            ],
            'message' => 'PDF generated successfully',
        ]);
    }

    public function markPaid(Invoice $invoice): JsonResponse
    {
        if ($invoice->status === 'paid') {
            return response()->json([
                'success' => false,
                'message' => 'Invoice is already marked as paid',
            ], 422);
        }

        $invoice->update([
            'status' => 'paid',
            'paid_at' => now(),
        ]);

        // Update order payment status
        $invoice->order->update(['payment_status' => 'paid']);

        return response()->json([
            'success' => true,
            'data' => $invoice->fresh(),
            'message' => 'Invoice marked as paid',
        ]);
    }

    public function show(Invoice $invoice): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => $invoice->load(['order.user', 'order.items.product']),
            'message' => 'Invoice retrieved successfully',
        ]);
    }

    public function download(Invoice $invoice)
    {
        if (!$invoice->pdf_path) {
            return response()->json([
                'success' => false,
                'message' => 'PDF not generated yet',
            ], 404);
        }

        $path = storage_path('app/public/' . $invoice->pdf_path);
        
        if (!file_exists($path)) {
            return response()->json([
                'success' => false,
                'message' => 'PDF file not found',
            ], 404);
        }

        return response()->download($path);
    }
}
