<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReportController extends Controller
{
    public function salesReport(Request $request): JsonResponse
    {
        try {
            $period = $request->get('period', 'daily'); // daily, weekly, monthly, yearly
            $dateFrom = $request->get('date_from');
            $dateTo = $request->get('date_to');

            $query = Order::where('payment_status', 'paid');

            // Apply date filters
            if ($dateFrom && $dateTo) {
                $query->whereBetween('created_at', [$dateFrom, $dateTo]);
            } else {
                // Default to last 30 days if no dates provided
                $query->where('created_at', '>=', now()->subDays(30));
            }

            $orders = $query->get();

            // Group by period
            $groupedData = $orders->groupBy(function ($order) use ($period) {
                switch ($period) {
                    case 'daily':
                        return $order->created_at->format('Y-m-d');
                    case 'weekly':
                        return $order->created_at->format('Y-W');
                    case 'monthly':
                        return $order->created_at->format('Y-m');
                    case 'yearly':
                        return $order->created_at->format('Y');
                    default:
                        return $order->created_at->format('Y-m-d');
                }
            });

            $reportData = [];
            foreach ($groupedData as $periodKey => $periodOrders) {
                $reportData[] = [
                    'period' => $periodKey,
                    'orders_count' => $periodOrders->count(),
                    'total_revenue' => $periodOrders->sum('total_amount'),
                    'average_order_value' => $periodOrders->avg('total_amount'),
                ];
            }

            // Calculate totals
            $totals = [
                'total_orders' => $orders->count(),
                'total_revenue' => $orders->sum('total_amount'),
                'average_order_value' => $orders->avg('total_amount'),
                'total_tax' => $orders->sum('tax_amount'),
                'total_shipping' => $orders->sum('shipping_cost'),
            ];

        return response()->json([
            'success' => true,
            'data' => [
                    'report_data' => $reportData,
                    'totals' => $totals,
                    'period' => $period,
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate sales report: ' . $e->getMessage()
            ], 500);
        }
    }

    public function productSalesReport(Request $request): JsonResponse
    {
        try {
            $dateFrom = $request->get('date_from');
            $dateTo = $request->get('date_to');
            $limit = $request->get('limit', 20);

            $query = OrderItem::with('product')
                             ->join('orders', 'order_items.order_id', '=', 'orders.id')
                             ->where('orders.payment_status', 'paid');

            if ($dateFrom && $dateTo) {
                $query->whereBetween('orders.created_at', [$dateFrom, $dateTo]);
            } else {
                $query->where('orders.created_at', '>=', now()->subDays(30));
            }

            $productSales = $query->select([
                'order_items.product_id',
                'order_items.product_name',
                DB::raw('SUM(order_items.quantity) as total_quantity_sold'),
                DB::raw('SUM(order_items.subtotal) as total_revenue'),
                DB::raw('AVG(order_items.unit_price) as average_price'),
                DB::raw('COUNT(DISTINCT order_items.order_id) as orders_count'),
            ])
            ->groupBy('order_items.product_id', 'order_items.product_name')
            ->orderBy('total_quantity_sold', 'desc')
            ->limit($limit)
            ->get();

        return response()->json([
            'success' => true,
                'data' => $productSales
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate product sales report: ' . $e->getMessage()
            ], 500);
        }
    }


    public function dashboardStats(): JsonResponse
    {
        try {
            $today = now()->startOfDay();
            $thisMonth = now()->startOfMonth();
            $lastMonth = now()->subMonth()->startOfMonth();

            // Today's stats
            $todayOrders = Order::whereDate('created_at', $today)->count();
            $todayRevenue = Order::whereDate('created_at', $today)
                               ->where('payment_status', 'paid')
                               ->sum('total_amount');

            // This month's stats
            $monthOrders = Order::where('created_at', '>=', $thisMonth)->count();
            $monthRevenue = Order::where('created_at', '>=', $thisMonth)
                               ->where('payment_status', 'paid')
                               ->sum('total_amount');

            // Last month's stats
            $lastMonthOrders = Order::whereBetween('created_at', [$lastMonth, $thisMonth])->count();
            $lastMonthRevenue = Order::whereBetween('created_at', [$lastMonth, $thisMonth])
                                   ->where('payment_status', 'paid')
                                   ->sum('total_amount');

            // Inventory stats
            $lowStockThreshold = 10; // Default threshold
            $lowStockCount = Product::where('stock_quantity', '>', 0)
                                  ->where('stock_quantity', '<=', $lowStockThreshold)
                                  ->count();
            $outOfStockCount = Product::where('stock_quantity', '<=', 0)->count();

            // Top selling products
            $topProducts = OrderItem::with('product')
                                  ->join('orders', 'order_items.order_id', '=', 'orders.id')
                                  ->where('orders.payment_status', 'paid')
                                  ->where('orders.created_at', '>=', $thisMonth)
                                  ->select([
                                      'order_items.product_id',
                                      'order_items.product_name',
                                      DB::raw('SUM(order_items.quantity) as total_sold'),
                                      DB::raw('SUM(order_items.subtotal) as total_revenue'),
                                  ])
                                  ->groupBy('order_items.product_id', 'order_items.product_name')
                                  ->orderBy('total_sold', 'desc')
                                  ->limit(5)
        ->get();

        // Recent orders
            $recentOrders = Order::with(['items.product'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

            $stats = [
                'today' => [
                    'orders' => $todayOrders,
                    'revenue' => $todayRevenue,
                ],
                'this_month' => [
                    'orders' => $monthOrders,
                    'revenue' => $monthRevenue,
                ],
                'last_month' => [
                    'orders' => $lastMonthOrders,
                    'revenue' => $lastMonthRevenue,
                ],
                'growth' => [
                    'orders_growth' => $lastMonthOrders > 0 ? 
                        round((($monthOrders - $lastMonthOrders) / $lastMonthOrders) * 100, 2) : 0,
                    'revenue_growth' => $lastMonthRevenue > 0 ? 
                        round((($monthRevenue - $lastMonthRevenue) / $lastMonthRevenue) * 100, 2) : 0,
                ],
                'inventory' => [
                    'low_stock' => $lowStockCount,
                    'out_of_stock' => $outOfStockCount,
                ],
                'top_products' => $topProducts,
                'recent_orders' => $recentOrders,
            ];

            return response()->json([
                'success' => true,
                'data' => $stats
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch dashboard statistics: ' . $e->getMessage()
            ], 500);
        }
    }

    public function exportSalesReport(Request $request): JsonResponse
    {
        try {
            $period = $request->get('period', 'monthly');
            $dateFrom = $request->get('date_from');
            $dateTo = $request->get('date_to');

            // This would typically generate a CSV or Excel file
            // For now, we'll return the data that would be exported
            $reportData = $this->salesReport($request)->getData(true);

        return response()->json([
            'success' => true,
                'message' => 'Export data prepared successfully',
                'data' => $reportData['data']
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to export sales report: ' . $e->getMessage()
            ], 500);
        }
    }
}