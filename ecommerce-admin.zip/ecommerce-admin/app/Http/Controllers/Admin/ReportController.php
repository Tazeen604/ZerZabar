<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function sales(Request $request): JsonResponse
    {
        $query = Order::where('status', '!=', 'cancelled');

        // Date range filter
        if ($request->has('date_from')) {
            $query->whereDate('created_at', '>=', $request->get('date_from'));
        }

        if ($request->has('date_to')) {
            $query->whereDate('created_at', '<=', $request->get('date_to'));
        }

        $sales = $query->selectRaw('
            COUNT(*) as total_orders,
            SUM(total_amount) as total_revenue,
            AVG(total_amount) as average_order_value,
            SUM(CASE WHEN status = "delivered" THEN total_amount ELSE 0 END) as completed_revenue
        ')->first();

        // Daily sales for chart
        $dailySales = $query->selectRaw('
            DATE(created_at) as date,
            COUNT(*) as orders_count,
            SUM(total_amount) as revenue
        ')
        ->groupBy('date')
        ->orderBy('date')
        ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'summary' => $sales,
                'daily_sales' => $dailySales,
            ],
            'message' => 'Sales report generated successfully',
        ]);
    }

    public function inventory(Request $request): JsonResponse
    {
        $query = Inventory::with(['product.category']);

        // Filter by low stock
        if ($request->has('low_stock')) {
            $query->where('quantity', '<=', 10);
        }

        $inventory = $query->selectRaw('
            COUNT(*) as total_products,
            SUM(quantity) as total_stock,
            SUM(quantity * cost_price) as total_value,
            COUNT(CASE WHEN quantity = 0 THEN 1 END) as out_of_stock,
            COUNT(CASE WHEN quantity <= 10 AND quantity > 0 THEN 1 END) as low_stock
        ')->first();

        // Top selling products
        $topSelling = Product::with(['category'])
            ->withCount(['orderItems as total_sold' => function ($query) {
                $query->selectRaw('SUM(quantity)');
            }])
            ->orderBy('total_sold', 'desc')
            ->limit(10)
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'summary' => $inventory,
                'top_selling' => $topSelling,
            ],
            'message' => 'Inventory report generated successfully',
        ]);
    }

    public function orders(Request $request): JsonResponse
    {
        $query = Order::query();

        // Date range filter
        if ($request->has('date_from')) {
            $query->whereDate('created_at', '>=', $request->get('date_from'));
        }

        if ($request->has('date_to')) {
            $query->whereDate('created_at', '<=', $request->get('date_to'));
        }

        $orders = $query->selectRaw('
            status,
            COUNT(*) as count,
            SUM(total_amount) as total_amount
        ')
        ->groupBy('status')
        ->get();

        // Recent orders
        $recentOrders = Order::with(['user'])
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'status_breakdown' => $orders,
                'recent_orders' => $recentOrders,
            ],
            'message' => 'Orders report generated successfully',
        ]);
    }

    public function dashboard(): JsonResponse
    {
        // Quick stats
        $stats = [
            'total_orders' => Order::count(),
            'total_revenue' => Order::where('status', '!=', 'cancelled')->sum('total_amount'),
            'total_products' => Product::count(),
            'low_stock_products' => Inventory::where('quantity', '<=', 10)->count(),
            'pending_orders' => Order::where('status', 'pending')->count(),
            'completed_orders' => Order::where('status', 'delivered')->count(),
        ];

        // Recent orders
        $recentOrders = Order::with(['user'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // Top products
        $topProducts = Product::withCount(['orderItems as total_sold' => function ($query) {
            $query->selectRaw('SUM(quantity)');
        }])
        ->orderBy('total_sold', 'desc')
        ->limit(5)
        ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'stats' => $stats,
                'recent_orders' => $recentOrders,
                'top_products' => $topProducts,
            ],
            'message' => 'Dashboard data retrieved successfully',
        ]);
    }
}
