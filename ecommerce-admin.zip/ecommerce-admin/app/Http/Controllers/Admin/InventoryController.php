<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Inventory;
use App\Models\InventoryHistory;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class InventoryController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Inventory::with(['product.category']);

        // Search
        if ($request->has('search')) {
            $search = $request->get('search');
            $query->whereHas('product', function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('sku', 'like', "%{$search}%");
            });
        }

        // Filter by low stock
        if ($request->has('low_stock')) {
            $query->where('quantity', '<=', 10);
        }

        // Filter by out of stock
        if ($request->has('out_of_stock')) {
            $query->where('quantity', 0);
        }

        $inventory = $query->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $inventory,
            'message' => 'Inventory retrieved successfully',
        ]);
    }

    public function adjustStock(Request $request, Product $product): JsonResponse
    {
        $request->validate([
            'quantity_change' => 'required|integer',
            'reason' => 'required|string|max:255',
            'reference' => 'nullable|string|max:255',
        ]);

        DB::beginTransaction();

        try {
            $inventory = $product->inventory;
            if (!$inventory) {
                $inventory = $product->inventory()->create(['quantity' => 0]);
            }

            $quantityBefore = $inventory->quantity;
            $quantityAfter = $quantityBefore + $request->quantity_change;

            if ($quantityAfter < 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Insufficient stock. Cannot reduce below zero.',
                ], 422);
            }

            // Update inventory
            $inventory->update(['quantity' => $quantityAfter]);

            // Create history record
            InventoryHistory::create([
                'product_id' => $product->id,
                'user_id' => auth()->id(),
                'type' => $request->quantity_change > 0 ? 'in' : 'out',
                'quantity_change' => $request->quantity_change,
                'quantity_before' => $quantityBefore,
                'quantity_after' => $quantityAfter,
                'reason' => $request->reason,
                'reference' => $request->reference,
            ]);

            // Update product stock status
            $status = $quantityAfter > 10 ? 'in_stock' : 
                     ($quantityAfter > 0 ? 'low_stock' : 'out_of_stock');
            $product->update([
                'stock_quantity' => $quantityAfter,
                'stock_status' => $status,
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'data' => $inventory->fresh(),
                'message' => 'Stock adjusted successfully',
            ]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'success' => false,
                'message' => 'Failed to adjust stock: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function lowStockReport(): JsonResponse
    {
        $lowStockProducts = Inventory::with(['product.category'])
            ->where('quantity', '<=', 10)
            ->orderBy('quantity', 'asc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $lowStockProducts,
            'message' => 'Low stock report generated successfully',
        ]);
    }

    public function history(Product $product): JsonResponse
    {
        $history = InventoryHistory::with(['user'])
            ->where('product_id', $product->id)
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $history,
            'message' => 'Inventory history retrieved successfully',
        ]);
    }
}
