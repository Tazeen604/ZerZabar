<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\InventoryHistory;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class InventoryController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        try {
            $query = Product::with(['category', 'subcategory']);

            // Search by product ID, name, or SKU
            if ($request->has('search') && $request->search) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('product_id', 'like', "%{$search}%")
                      ->orWhere('name', 'like', "%{$search}%")
                  ->orWhere('sku', 'like', "%{$search}%");
            });
        }

            // Filter by stock status
            if ($request->has('stock_status')) {
                switch ($request->stock_status) {
                    case 'in_stock':
                        $query->where('stock_quantity', '>', 10)
                              ->where('stock_status', 'in_stock');
                        break;
                    case 'low_stock':
                        $query->where('stock_quantity', '>', 0)
                              ->where('stock_quantity', '<=', 10)
                              ->orWhere('stock_status', 'low_stock');
                        break;
                    case 'out_of_stock':
                        $query->where('stock_quantity', '<=', 0)
                              ->orWhere('stock_status', 'out_of_stock');
                        break;
                }
            }

            // Filter by category
            if ($request->has('category_id') && $request->category_id) {
                $query->where('category_id', $request->category_id);
            }

            $products = $query->orderByRaw('CASE WHEN stock_quantity <= 10 AND stock_quantity > 0 THEN 1 ELSE 0 END DESC')
                            ->orderBy('stock_quantity', 'asc')
                            ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
                'data' => $products
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch inventory: ' . $e->getMessage()
            ], 500);
        }
    }

    public function show($id): JsonResponse
    {
        try {
            $product = Product::with(['category', 'subcategory', 'inventoryHistory'])
                             ->findOrFail($id);

            return response()->json([
                'success' => true,
                'data' => $product
            ]);
        } catch (\Exception $e) {
                return response()->json([
                    'success' => false,
                'message' => 'Product not found: ' . $e->getMessage()
            ], 404);
        }
    }

    public function updateStock(Request $request, $id): JsonResponse
    {
        try {
            $product = Product::findOrFail($id);

            $validated = $request->validate([
                'stock_quantity' => 'required|integer|min:0',
                'low_stock_threshold' => 'nullable|integer|min:0',
                'track_stock' => 'nullable|boolean',
                'notes' => 'nullable|string',
            ]);

            $oldStock = $product->stock_quantity;
            $newStock = $validated['stock_quantity'];
            $quantityChange = $newStock - $oldStock;

            $product->update([
                'stock_quantity' => $newStock,
                'low_stock_threshold' => $validated['low_stock_threshold'] ?? $product->low_stock_threshold,
                'track_stock' => $validated['track_stock'] ?? $product->track_stock,
            ]);

            // Update low stock status
            $product->updateLowStockStatus();

            // Create inventory history record
            if ($quantityChange != 0) {
                $product->inventoryHistory()->create([
                    'type' => 'adjustment', // Map all changes to 'adjustment' for database compatibility
                    'quantity_change' => abs($quantityChange),
                    'quantity_before' => $oldStock,
                    'quantity_after' => $newStock,
                    'reason' => $validated['notes'] ?? 'Stock manually adjusted',
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Stock updated successfully',
                'data' => $product->fresh()
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update stock: ' . $e->getMessage()
            ], 500);
        }
    }

    public function adjustStock(Request $request, $id): JsonResponse
    {
        try {
            $product = Product::findOrFail($id);

            $validated = $request->validate([
                'quantity' => 'required|integer',
                'type' => 'required|in:add,subtract,set',
                'notes' => 'nullable|string',
            ]);

            $oldStock = $product->stock_quantity;
            $quantity = $validated['quantity'];

            switch ($validated['type']) {
                case 'add':
                    $newStock = $oldStock + $quantity;
                    break;
                case 'subtract':
                    $newStock = max(0, $oldStock - $quantity);
                    break;
                case 'set':
                    $newStock = $quantity;
                    break;
            }

            // Directly update the stock quantity
            $product->stock_quantity = $newStock;
            $product->save();
            
            // Update low stock status
            $product->updateLowStockStatus();

            // Map frontend type to database enum value
            $historyType = 'adjustment'; // All manual adjustments are recorded as 'adjustment'

            // Create inventory history record
            $product->inventoryHistory()->create([
                'type' => $historyType,
                'quantity_change' => $quantity,
                'quantity_before' => $oldStock,
                'quantity_after' => $newStock,
                'reason' => $validated['notes'] ?? 'Stock adjusted',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Stock adjusted successfully',
                'data' => $product->fresh()
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to adjust stock: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getLowStock(): JsonResponse
    {
        try {
            $lowStockThreshold = Setting::get('low_stock_threshold', 10);
            $outOfStockThreshold = Setting::get('out_of_stock_threshold', 0);
            
            $lowStockProducts = Product::where(function($query) use ($lowStockThreshold, $outOfStockThreshold) {
                $query->where('stock_quantity', '>', $outOfStockThreshold)
                      ->where('stock_quantity', '<=', $lowStockThreshold);
            })->orWhere('stock_quantity', '<=', $outOfStockThreshold)
              ->with(['category', 'subcategory'])
              ->orderBy('stock_quantity', 'asc')
              ->get();

            return response()->json([
                'success' => true,
                'data' => $lowStockProducts
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch low stock products: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getInventoryStats(): JsonResponse
    {
        try {
            $lowStockThreshold = Setting::get('low_stock_threshold', 10);
            $outOfStockThreshold = Setting::get('out_of_stock_threshold', 0);
            
            $stats = [
                'total_products' => Product::count(),
                'in_stock' => Product::where('stock_quantity', '>', $lowStockThreshold)->count(),
                'low_stock' => Product::where('stock_quantity', '>', $outOfStockThreshold)
                                   ->where('stock_quantity', '<=', $lowStockThreshold)
                                   ->count(),
                'out_of_stock' => Product::where('stock_quantity', '<=', $outOfStockThreshold)->count(),
                'total_inventory_value' => Product::sum(DB::raw('stock_quantity * price')),
                'low_stock_threshold' => $lowStockThreshold,
            ];

            return response()->json([
                'success' => true,
                'data' => $stats
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch inventory statistics: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getInventoryHistory($id): JsonResponse
    {
        try {
            $product = Product::findOrFail($id);
            $history = $product->inventoryHistory()
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return response()->json([
            'success' => true,
                'data' => $history
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch inventory history: ' . $e->getMessage()
            ], 500);
        }
    }

    public function bulkUpdateStock(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'products' => 'required|array',
                'products.*.id' => 'required|exists:products,id',
                'products.*.stock_quantity' => 'required|integer|min:0',
                'products.*.notes' => 'nullable|string',
            ]);

            DB::beginTransaction();

            foreach ($validated['products'] as $productData) {
                $product = Product::find($productData['id']);
                $oldStock = $product->stock_quantity;
                $newStock = $productData['stock_quantity'];

                $product->update([
                    'stock_quantity' => $newStock,
                ]);

                $product->updateLowStockStatus();

                // Create inventory history
                if ($newStock != $oldStock) {
                    $product->inventoryHistory()->create([
                        'type' => 'adjustment', // Map bulk_update to adjustment for database compatibility
                        'quantity_change' => abs($newStock - $oldStock),
                        'quantity_before' => $oldStock,
                        'quantity_after' => $newStock,
                        'reason' => $productData['notes'] ?? 'Bulk stock update',
                    ]);
                }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Bulk stock update completed successfully'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to update stock: ' . $e->getMessage()
            ], 500);
        }
    }
}